// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
// const { DateResolverDialog } = require('./dateResolverDialog');
const { CardFactory } = require('botbuilder-core');

const CONFIRM_PROMPT = 'confirmPrompt';
// const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class AorRReport extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'AorRReport');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            // .addDialog(new DateResolverDialog(DATE_RESOLVER_DIALOG))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.SRId.bind(this),
                 this.emailIdDetail.bind(this),
                this.interfaceDetail.bind(this),
                this.commentDetail.bind(this),               
                this.confirmStep.bind(this),
                this.finalStep.bind(this),         
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    /**
     * If a destination city has not been provided, prompt for one.
     */
    async SRId(stepContext) {
        const bookingDetails = stepContext.options;
        console.log("Intent name is: ", bookingDetails);        
        if (!bookingDetails.SRId ) {
            return await stepContext.prompt(TEXT_PROMPT,'Please enter the **Interface name**' );
        } 
        else 
        {
            return await stepContext.next(bookingDetails.SRId_value);
        }
    }

    async emailIdDetail(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the response to the previous step's prompt
        bookingDetails.SRId = stepContext.result;
        if (!bookingDetails.emailId) {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please mention the **Report name**  for updation' });
        } else {
            return await stepContext.next(bookingDetails.emailId_value);
        }
    }
    
    async interfaceDetail(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the response to the previous step's prompt
        bookingDetails.emailId_value = stepContext.result;
        if (!bookingDetails.interfaceName) {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please enter the respective **field name**: ' });
        } else {
            //  bookingDetails.editor_name
            return await stepContext.next(bookingDetails.interfaceName_value);
            
        }
    }
      
       async commentDetail(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the response to the previous step's prompt
        bookingDetails.interfaceName_value = stepContext.result;
        if (!bookingDetails.comment) {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please write comment on the mentioned issue.' });
        } else {
            //  bookingDetails.editor_name
            return await stepContext.next(bookingDetails.comment_value);
            
        }
    }
    
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the results of the previous step
        bookingDetails.comment = stepContext.result;
               
        const Text = [
                     ];


// const card = CardFactory.heroCard('', undefined,
//             Text, { text: 'You hav provided the following details. \n\n**Entity ID** \t\t: '+ bookingDetails.entityID + '\n\n **Editor Name**:\t\t' + bookingDetails.editor_name +'\n\n **Recommended Name**:\t\t'+bookingDetails.recomnded_name_string + '\n\n **Please confirm if this information is correct?**'   });

 await stepContext.context.sendActivity("Thanks, this is what you’ve told me:\n\n**Update on Report fields**\n**Action on report**: "+ bookingDetails.AorR_data_value +'\n **Interface name**\t'+bookingDetails.SRId +"\n**Report name**: "+bookingDetails.emailId_value+"\n**Field name**: "+bookingDetails.interfaceName_value+"\n**Comments**: "+bookingDetails.comment);
  // var description="Following are the details: "+"\nAction on Report:"+result.AorR_data_value+"\nInterface name:"+result.SRId+"\nReport name: "+result.emailId_value+"\nField name: "+result.interfaceName_value+"\nComments"+result.comment_value;
       
 const card = CardFactory.heroCard('', undefined,
            Text, { text: "Do you want to submit this request?"});            
return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
    
    }
    

    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;

            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

module.exports.AorRReport = AorRReport;