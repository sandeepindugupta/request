// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,ActionTypes,MessageFactory,TurnContext} = require('botbuilder');
const { LuisRecognizer } = require('botbuilder-ai');
const { CardFactory } = require('botbuilder-core');
const { QnAMaker } = require('botbuilder-ai');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
// const { ChoiceFactory } = require('botbuilder-choices');
const {arReport}=require("./adaptiveCards/add_remove_report.json");
const {servicereq}=require("./adaptiveCards/serviceReq.json");
const {AorRInput}=require("./AorRInput");
const {AORRINPUT}='AorRInput';

class LuisHelper extends CancelAndHelpDialog {
    /**
     * Returns an object with preformatted LUIS results for the bot's dialogs to consume.
     * @param {*} logger
     * @param {TurnContext} context
     */
    static async executeLuisQuery(logger, context) {    const bookingDetails = {};

    try {
        const recognizer = new LuisRecognizer({
            applicationId: process.env.LuisAppId,
            endpointKey: process.env.LuisAPIKey,
            endpoint: `https://${ process.env.LuisAPIHostName }`
        }, {}, true);

        const recognizerResult = await recognizer.recognize(context);

        const intent = LuisRecognizer.topIntent(recognizerResult);
        console.log("recognizerResult ", recognizerResult);
        console.log("Intent is ::::::: flow 5", intent);
        bookingDetails.intent = intent;
        var intentScore;
        if (recognizerResult.text != '') {
            intentScore = recognizerResult.luisResult.topScoringIntent.score;
        }

        console.log("score value::", intentScore);




        if (intentScore != null && intentScore > 0.50) { //condition to check for threshold
            
           
            
             if (intent === 'AorR_mail') {
                const entity_data = recognizerResult.luisResult.entities;
                console.log("Entity complete data  is ", entity_data);
                console.log("length of Entity is", entity_data.length);
                if (entity_data.length == 0) {
                    

       const reply = { type: ActivityTypes.Message };

        const buttons = [
            { type: ActionTypes.ImBack, title: 'Add in e-mail chain ', value: 'Add in e-mail chain' },
            { type: ActionTypes.ImBack, title: 'Remove from e-mail chain ', value: 'Remove from e-mail chain' }
        ];

        const card = CardFactory.heroCard('', undefined,
            buttons, { text: 'Please select one of the options below:' });

        reply.attachments = [card];

                
               return  await context.sendActivity(reply);

             
                    
                }
                else {
                    for (var i = 0; i < entity_data.length; i++) {
                        if ((entity_data[i].entity == "add") ||(entity_data[i].entity == "remove")) {
                            
                            bookingDetails.AorR_data = entity_data[i].type;
                            bookingDetails.AorR_data_value = entity_data[i].entity;
                            console.log("inside add or REMOVE",bookingDetails);
                            // return await context.beginDialog("AorRInput", bookingDetails);
                            // console.log("Inside ENTITY", bookingDetails.AorR_data);
                        }
                        else if (entity_data[i].type == "SRId") {
                            bookingDetails.SRId = entity_data[i].type;
                            bookingDetails.SRId_value = entity_data[i].entity;
                            console.log("Inside recommend editor", bookingDetails.SRId);
                            break;
                        }
                        else if (entity_data[i].type == "builtin.email") {
                            bookingDetails.email = entity_data[i].type;
                            bookingDetails.email_value = entity_data[i].entity;
                            console.log("Inside editor", entity_data[i].entity);
                            break;
                        } else if (entity_data[i].type == "Interface Name") {
                            bookingDetails.interfaceName  = entity_data[i].type;
                            bookingDetails.interfaceName_value = entity_data[i].entity;
                            console.log("Inside editor", entity_data[i].entity);
                            break;
                        } else if (entity_data[i].type == "Comment") {
                            bookingDetails.comment  = entity_data[i].type;
                            bookingDetails.comment_value = entity_data[i].entity;
                            console.log("Inside editor", entity_data[i].entity);
                            break;
                        }


                    }
                }
                return bookingDetails;
            }
            
            else if (intent === 'AorR_report') {
                const entity_data = recognizerResult.luisResult.entities;
                console.log("Entity complete data  is ", entity_data);
                console.log("length of Entity is", entity_data.length);
                if (entity_data.length == 0) {
                const reply = { type: ActivityTypes.Message };

                const buttons = [
                             { type: ActionTypes.ImBack, title: 'Add fields in report', value: 'Add fields in report' },
                             { type: ActionTypes.ImBack, title: 'Remove fields in report', value: 'Remove fields in report' }
                                 ];

                const card = CardFactory.heroCard('', undefined,
                buttons, { text: 'Please select one of the options below:' });

                reply.attachments = [card];
               return  await context.sendActivity(reply);
                    
                    
               
                    //  return await context.beginDialog("EntityEditorsUpdate", bookingDetails);
                    
                }
                else {
                    for (var i = 0; i < entity_data.length; i++) {
                       if ((entity_data[i].entity == "add") ||(entity_data[i].entity == "remove")) {
                            bookingDetails.AorR_data = entity_data[i].type;
                            bookingDetails.AorR_data_value = entity_data[i].entity;
                            // return await context.beginDialog('AorRReport', bookingDetails);
                            // console.log("Inside ENTITY", bookingDetails.AorR_data);
                        }
                        else if (entity_data[i].type == "SRId") {
                            bookingDetails.SRId = entity_data[i].type;
                            bookingDetails.SRId_value = entity_data[i].entity;
                            console.log("Inside recommend editor", bookingDetails.SRId);
                            break;
                        }
                        else if (entity_data[i].type == "email") {
                            bookingDetails.email = entity_data[i].type;
                            bookingDetails.email_value = entity_data[i].entity;
                            console.log("Inside editor", entity_data[i].entity);
                            break;
                        } else if (entity_data[i].type == "Interface Name") {
                            bookingDetails.interfaceName  = entity_data[i].type;
                            bookingDetails.interfaceName_value = entity_data[i].entity;
                            console.log("Inside editor", entity_data[i].entity);
                            break;
                        } else if (entity_data[i].type == "Comment") {
                            bookingDetails.comment  = entity_data[i].type;
                            bookingDetails.comment_value = entity_data[i].entity;
                            console.log("Inside editor", entity_data[i].entity);
                            break;
                        }


                    }
                }
                return bookingDetails;
            }
       
           
           else if (intent === 'service_request') {
               const reply = { type: ActivityTypes.Message };

                const buttons = [
                             { type: ActionTypes.ImBack, title: 'Manhattan ', value: 'Manhattan ' },
                             { type: ActionTypes.ImBack, title: 'Tymetrix ', value: 'Tymetrix ' },
                             { type: ActionTypes.ImBack, title: 'Other interface issue ', value: 'Other interface issue ' }
                                 ];

                const card = CardFactory.heroCard('', undefined,
                buttons, { text: 'Please select one of the options below:' });

                reply.attachments = [card];
               return  await context.sendActivity(reply);
              
               
           }
           else if(intent === 'Manhattan'){
               
               return bookingDetails;
           }
           else if(intent === 'Tymetrix'){
               
               return bookingDetails;
           }
           else if(intent === 'Other_interface_issue'){
                // bookingDetails.intent = "Other_interface_issue";  
                // console.log("booking detail value :", bookingDetails);
            // return   await context.prompt('textPrompt', 'Please enter your interface issue');
               return bookingDetails;
           }
            else if (intent === 'None') {
                return bookingDetails;
            }
            
        }//score if ends here
   else if (intentScore != null && intentScore < 0.50) {      
       // await context.sendActivity("I’m sorry, I don’t understand the question. Could you please try rephrasing it so that I can better assist you? I want to help.. ");
               bookingDetails.intent = "None";               
                return bookingDetails;
            }
        
    } catch (err) {
        logger.warn(`LUIS Exception: ${ err } Check your LUIS configuration`);
    }
    return bookingDetails;
}


}

module.exports.LuisHelper = LuisHelper;