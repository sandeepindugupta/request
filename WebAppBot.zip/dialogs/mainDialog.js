// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { ComponentDialog, DialogSet,ConfirmPrompt, DialogTurnStatus, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { AorRInput} = require('./AorRInput');
const { AorRReport} = require('./AorRReport');
const { LuisHelper } = require('./luisHelper');
const welcome_LEM = require('./AdaptiveCards/againWelcome.json');
const { CardFactory } = require('botbuilder-core');
const { manhattan} = require('./manhattan');
const { tymetrix} = require('./tymetrix');
const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
// const BOOKING_DIALOG = 'bookingDialog';
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const AORRINPUT = 'AorRInput';
const AORREPORT='AorRReport';
const MANHATTAN='manhattan';
const TYMETRIX='tymetrix';
// const timer=require('await-timeout ');
class MainDialog extends ComponentDialog {
    constructor(logger) {
        super('MainDialog');

        if (!logger) {
            logger = console;
            logger.log('[MainDialog]: logger not passed in, defaulting to console');
        }

        this.logger = logger;

        // Define the main dialog and its related components.
        // This is a sample "book a flight" dialog.
        this.addDialog(new TextPrompt(TEXT_PROMPT))
        .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
        // .addDialog(new BookingDialog(BOOKING_DIALOG))
            .addDialog(new AorRInput(AORRINPUT))
            .addDialog(new AorRReport(AORREPORT))
            .addDialog(new manhattan(MANHATTAN))
            .addDialog(new tymetrix(TYMETRIX))
            .addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
            this.actStep.bind(this),
            this.finalStep.bind(this)
        ]));

        this.initialDialogId = MAIN_WATERFALL_DIALOG;
    }


    /**
     * The run method handles the incoming activity (in the form of a DialogContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {*} dialogContext
     */
    async run(turnContext, accessor) {
    const dialogSet = new DialogSet(accessor);
    dialogSet.add(this);

    const dialogContext = await dialogSet.createContext(turnContext);
    const results = await dialogContext.continueDialog();

    console.log("status result", results.status);
    


    
    
    
    console.log("status result", DialogTurnStatus.empty);

    if (results.status === DialogTurnStatus.empty) {
        await dialogContext.beginDialog(this.id);
    }
}
    async actStep(stepContext) {
        let bookingDetails = {};
        let bookingDetails1 = {};
        console.log("Inside actstep :::flow 3");

        if (process.env.LuisAppId && process.env.LuisAPIKey && process.env.LuisAPIHostName) {
            console.log("Inside Luis ");
            bookingDetails = await LuisHelper.executeLuisQuery(this.logger, stepContext.context);

            this.logger.log('LUIS extracted these booking details:', bookingDetails);
        }

        if (bookingDetails.intent == 'service_request') {
            return await stepContext.endDialog();
        }
        else if (bookingDetails.intent == 'Legal_entitty_bsns_issues') {
            const Issues_LE_bsns_data1 = CardFactory.adaptiveCard(Issues_LE_bsns_data);
            return await stepContext.context.sendActivity({ attachments: [Issues_LE_bsns_data1] });
            // return bookingDetails;
            // return await stepContext.endDialog();
        } else if (bookingDetails.intent === 'Manhattan') {
           return await stepContext.beginDialog("manhattan", bookingDetails);
        } 
        else if (bookingDetails.intent == 'Tymetrix') {
            return await stepContext.beginDialog("tymetrix", bookingDetails);
          
        }
        //Other_LEM/LPE_data_issue    Other LEM/LPE data issue
        else if (bookingDetails.intent == 'Other_LEM/LPE_data_issue') {
            return await stepContext.endDialog();
            // return await stepContext.next(stepContext);
          
        }
        
      
        
        else if (bookingDetails.intent == "AorR_mail") {
            
            return await stepContext.beginDialog("AorRInput", bookingDetails);
            // return await stepContext.endDialog();
        
        }else if (bookingDetails.intent == "AorR_report") {
            return await stepContext.beginDialog("AorRReport", bookingDetails);
            // return  stepContext.endDialog();
        
        }
        
        else if (bookingDetails.intent == "Other_interface_issue") {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please enter the other interface issue details here...' });
            
            // const Text=[];
            // const card = CardFactory.heroCard('', undefined,
            // Text, { text: "Do you want to submit this request?"});            
          // return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
            // return await stepContext.endDialog();   
        
        }  
        
         
        
        else if (bookingDetails.intent == "None") {
            let Api_input_values = {};
            console.log("7777777777", stepContext);
            
            if (stepContext.context.activity.text)
            { 
                if(stepContext.context.activity.text=="Yes"){
                  const welcome_again = CardFactory.adaptiveCard(welcome_LEM);
            return await stepContext.context.sendActivity({ attachments: [welcome_again] });  
                }else if(stepContext.context.activity.text=="No"){
                  stepContext.context.sendActivity("Thank you.Have a nice day! ");
                  return await stepContext.endDialog();  
                }else{
                console.log("sorry message");
                stepContext.context.sendActivity("I’m sorry, I don’t understand the question. Could you please try rephrasing it so that I can better assist you? I want to help.");
                return await stepContext.endDialog();
                }
            }
          
          // if (stepContext.context.activity.value.entityId !== '' || stepContext.context.activity.value.entityName !== null) {
          if (stepContext.context.activity.value !== undefined)
          {
              console.log("Comment value is: ", stepContext.context.activity.value.comment);
          if (stepContext.context.activity.value.entityId !== '' && stepContext.context.activity.value.entityId !== undefined && stepContext.context.activity.value.entityName!== '' && stepContext.context.activity.value.entityName!== undefined && stepContext.context.activity.value.comment!=='' && stepContext.context.activity.value.comment!==undefined ) {
                
                //check for Tax jurisdiction data value
                const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
                 Api_input_values.entityId = stepContext.context.activity.value.entityId;
                Api_input_values.entityName = stepContext.context.activity.value.entityName;
                Api_input_values.comment=stepContext.context.activity.value.comment;
                console.log("API call inside comment", Api_input_values);
                stepContext.context.sendActivity(`ContactOne ticket has been created successfully. Support team will contact you shortly.`);
            //*****************************************************************    
                await timeout(3000); 
                
                  var reply = MessageFactory.suggestedActions(['Yes', 'No'], 'Is there anything else I can help you with?');
                  await stepContext.context.sendActivity(reply);
                
                    
                    

//**********************************************************************************************
                
                //return await stepContext.beginDialog('APICall',Api_input_values);
               // return Api_input_values = await APICall.executeAPIcall(this.logger, stepContext.context);
                 return await stepContext.endDialog();              
          }
          
//            else if (stepContext.context.activity.value.entityId !== '' && stepContext.context.activity.value.entityId !== undefined) {
                
//                 Api_input_values.entityId = stepContext.context.activity.value.entityId;
//                 Api_input_values.entityName = stepContext.context.activity.value.entityName;
//                 console.log("activity value168:",stepContext.context.activity.value);
//                 console.log("API call inside", Api_input_values);
                
//                 var request = require("request");

// var options = { method: 'POST',
//   url: 'https://lem-dev.swissre.com/ids/connect/token',
//   // url: 'https://10.92.40.27/ids/connect/token',
//   headers: {
//    // { 'cache-control': 'no-cache',
//     //  Connection: 'keep-alive',
//     //  'content-length': '154',
//     //  'accept-encoding': 'gzip, deflate',
//     //  Host: 'lem-dev.swissre.com',
//     //  'Postman-Token': '72dfd19f-0337-451c-a381-9089f87ec52d,86130c2e-ac2a-4782-8a06-1cb7dab01d4f',
//     //  'Cache-Control': 'no-cache',
//      // 'User-Agent': 'PostmanRuntime/7.11.0',
//      Accept : 'application/json',
//      'Content-Type': 'application/x-www-form-urlencoded' },
//   form:
//    { grant_type: 'password',
//      username: 'TECDRRT1',
//      password: 'Chatbot_dev',
//      scope: 'openid xtekUser offline_access',
//      client_id: 'xtekLocal',
//      client_secret: '4tFTxc0u0LZvYjky8imx' } };

// request(options, function (error, response, body) {
//   if (error) throw new Error(error);

//   // console.log("error is ",error);
//   // console.log("response is ",response);
//   console.log(body);
//   if(body!=null){
//       stepContext.context.sendActivity(` API got triggered.`);
//   }
// });
                                

//                  stepContext.context.sendActivity(`Need to trigger API with the provided inputs.`);
//                 //return await stepContext.beginDialog('APICall',Api_input_values);
//                // return Api_input_values = await APICall.executeAPIcall(this.logger, stepContext.context);
//                  return await stepContext.endDialog();
//             }
            // else if(stepContext.context.activity.value.comment!== '' && stepContext.context.activity.value.comment!==undefined){
                
            // // }
            // // else if (stepContext.context.activity.value) {
            //       const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
            //     stepContext.context.sendActivity(`ContactOne ticket has been created successfully. Support team will contact you shortly.`);
            //     // stepContext.context.sendActivity(`You have updated your address ${stepContext.context.activity.value.comment}`); 
            //    console.log("inside the ticket  CREATION:",stepContext.context.activity.value);
            //     await timeout(3000);
            //     console.log("after the timout");
            //      var reply = MessageFactory.suggestedActions(['Yes', 'No'], 'Is there anything else I can help you with?');
            //       await stepContext.context.sendActivity(reply);
            //     return await stepContext.endDialog();
            // }
            // else if (stepContext.context.activity.text )
            // {
            //     console.log("sorry message");
            // }
            
        }
            return await stepContext.endDialog();
        } else 
        {
            return await stepContext.endDialog();
        }

    }

/**
 * This is the final step in the main waterfall dialog.
 * It wraps up the sample "book a flight" interaction with a simple confirmation.
 */
async finalStep(stepContext) {
var incNumber="";
var sys_id = "";
console.log("value in result ", stepContext.result)
    if (stepContext.result) {
        const result = stepContext.result;
        // Now we have all the booking details.
    console.log("flow 4 final step",result);
    // var shortDesc= "I am having issue on "+result.intent;
    
    var request = require("request");
    if(result.firstSelection == 'Fetch MH Policy Number for a PINJ Policy Number')
    {
         const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
        await timeout(3000);
        var reply = MessageFactory.suggestedActions(['Yes', 'No'], 'Is there anything else I can help you with?');
        return  await stepContext.context.sendActivity(reply);
        //  return await stepContext.endDialog();
    }
   else if(result.intent=== "Manhattan"){
       var shortDesc= "I am having issue on "+result.intent;
       var description="Following are the details: " +"Field: "+result.intent +
 "\nRequest: "+ result.firstSelection + "\nStructure: "+ result.secondSelection +"\nPin policy number: "+result.thirdSelection;
  }
  else if(result.intent=== "AorR_mail"){
      var shortDesc= "I want to "+result.AorR_data_value+" person from email chain";
       var description="Following are the details: "+"\nAction on email chain:"+result.AorR_data_value+"\nSR Id:"+result.SRId+"\nEmail id of person: "+result.emailId_value+"\nInterface name: "+result.interfaceName_value+"\nComments"+result.comment_value;
       
  }
  else if(result.intent=== "AorR_report"){
      var shortDesc= "I want to "+result.AorR_data_value+" field from report";
       var description="Following are the details: "+"\nAction on Report:"+result.AorR_data_value+"\nInterface name:"+result.SRId+"\nReport name: "+result.emailId_value+"\nField name: "+result.interfaceName_value+"\nComments"+result.comment;
       
  }else if(result.intent=== "Tymetrix"){
      var shortDesc= "I am having issue on "+result.intent;
       var description="Following are the Tymetrix details: "+"\nTymetrix selection:"+result.firstSelection+"\nAction on tymetrix:"+result.secondSelection+"\nMatter number: "+result.thirdSelection+"\nInvoice number: "+result.fourthSelection+"\nVendor Id:"+result.fifthSelection+"\nSource System Id"+result.sixthSelection;
       
  }else{
      var shortDesc= "Interface issue";
       var description="Following are the Issue details: "+ result;
       
  }
  
/*var options = { method: 'POST',
  url: 'https://dev49290.service-now.com/api/now/table/incident', 
  headers: 
   { 'cache-control': 'no-cache',    
     Host: 'swissredevfour.service-now.com',
    //  'Postman-Token': 'eedf6f00-0cb1-4ca0-8e5a-9a3264419548,9b345091-4824-457f-a57e-4a95870d98ca',
     Authorization: 'Basic YWRtaW46U3dpc3NyZUAxMjM=',  
     'Content-Type': 'application/json',
     Accept: 'application/json' },
  body: 
   { short_description: shortDesc,
     category: 2,
     caller_id: 'Sudheer Peringanji',
     work_notes: 'Check work notes',
     assignment_group:'ES_CS0',
     contact_type: "Chatbot",
     description: description
      },
  json: true };*/
  
  
  var options = 
  { 
       method: 'POST',
      // url: 'https://dev49290.service-now.com/api/now/table/incident',
      url: 'https://swissredevfour.service-now.com/api/x_swre_operations/ops_ticketing/OpsTicket',
      headers: 
       { 'cache-control': 'no-cache',    
         Host: 'swissredevfour.service-now.com',
        //  'Postman-Token': 'eedf6f00-0cb1-4ca0-8e5a-9a3264419548,9b345091-4824-457f-a57e-4a95870d98ca',   
         Authorization: 'Basic VEVDTEVNOmxlbWJvdA==',
         'Content-Type': 'application/json',
         Accept: 'application/json' },
      body: 
       {
            user_id: "SRZ2SH"
       },
      json: true 
  
  };

request(options, function (error, response, body) {
  if (error) throw new Error(error);

  console.log("body od the api",body);
  incNumber=body.result.number;
  sys_id = body.result.sys_id;
  console.log("INCNUMBER23456",incNumber);
});

const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
     
     console.log("INCNUMBER",incNumber);  
        const msg = 'Thank you for all the details. Ticket has been created. Support team will get in touch with you soon.';
        await stepContext.context.sendActivity(msg);
        // const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
        await timeout(2000);
        // await stepContext.context.sendActivity("Following is the ticket number on your issue raised: "+`**${incNumber}**`);
       // console.log("ticket number is ",incNumber);
       // console.log("ticket number is ",typeof(incNumber));
       const ticket_number_card=this.card(incNumber, sys_id);
       const number_card = CardFactory.adaptiveCard(ticket_number_card);
       await stepContext.context.sendActivity({ attachments: [number_card] });
       
        await timeout(3000);
        var reply = MessageFactory.suggestedActions(['Yes', 'No'], 'Is there anything else I can help you with?');
                  await stepContext.context.sendActivity(reply);
    } else {
        await stepContext.context.sendActivity('Thank you for the confirmation. I will be ignoring all the provided details');
         const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
        await timeout(3000);
        var reply = MessageFactory.suggestedActions(['Yes', 'No'], 'Is there anything else I can help you with?');
                  await stepContext.context.sendActivity(reply);
    }
    return await stepContext.endDialog();
}

card(incNumber,sys_id){
     console.log("inside card123::",incNumber);
     var val;
     return val={
     "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [
        {
            "type": "ColumnSet",
            "columns": [
                {
                    "type": "Column",
                    "width": 2,
                    "items": [
                        {
                            "type": "TextBlock",
                            "text": "Following is the ticket ID created for the issue:",
                            "weight": "Bolder",
                            "size": "Medium",
                            "wrap": true
                        }
                        
                    ]
                }
            ]
        }
    ],
    "actions": [
        {
            "type": "Action.OpenUrl",
            "url": "https://swissredevfour.service-now.com/nav_to.do?uri=incident.do?sys_id="+sys_id,
            "title": incNumber
        }
    ]
}
}

}

module.exports.MainDialog = MainDialog;