// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const {ActivityTypes,ActionTypes,MessageFactory,TurnContext} = require('botbuilder');
// const { DateResolverDialog } = require('./dateResolverDialog');
const { CardFactory } = require('botbuilder-core');
// const test_json=require("./adaptiveCards/test_json.json");
const CONFIRM_PROMPT = 'confirmPrompt';
// const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class manhattan extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'manhattan');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            // .addDialog(new DateResolverDialog(DATE_RESOLVER_DIALOG))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.initialStep.bind(this),
                 this.secondStep.bind(this),
                this.thirdStep.bind(this),
                this.confirmStep.bind(this),
                this.finalStep.bind(this),         
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    /**
     * If a destination city has not been provided, prompt for one.
     */
    async initialStep(stepContext) {
        const bookingDetails = stepContext.options;
            const reply = { type: ActivityTypes.Message };

                const buttons = [
                             { type: ActionTypes.ImBack, title: 'Policy need to be marked to Success', value: 'Policy need to be marked to Success' },
                             { type: ActionTypes.ImBack, title: 'Add to exception list', value: 'Add to exception list' },
                             { type: ActionTypes.ImBack, title: 'Re-Trigger the policy', value: 'Re-Trigger the policy' },
                             { type: ActionTypes.ImBack, title: 'Fetch MH Policy Number for a PINJ Policy Number', value: 'Fetch MH Policy Number for a PINJ Policy Number' }
                                 ];

                const card = CardFactory.heroCard('', undefined,
                buttons, { text: 'Please select one of the below request:' });

                reply.attachments = [card];
                 await stepContext.context.sendActivity(reply);
                  return await stepContext.prompt('textPrompt', '');   
         
        // else 
        // {
        //     return await stepContext.next(bookingDetails.SRId_value);
        // }
    }

    async secondStep(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the response to the previous step's prompt
        bookingDetails.firstSelection = stepContext.result;
        console.log("first selection",typeof(bookingDetails.firstSelection));
        if((bookingDetails.firstSelection=="Policy need to be marked to Success") || (bookingDetails.firstSelection=="Re-Trigger the policy")){
               const reply = { type: ActivityTypes.Message };

                const buttons = [
                             { type: ActionTypes.ImBack, title: 'Line', value: 'Line' },
                             { type: ActionTypes.ImBack, title: 'Adjustment', value: 'Adjustment' },
                             { type: ActionTypes.ImBack, title: 'Booking', value: 'Booking' }
                                 ];

                const card = CardFactory.heroCard('', undefined,
                buttons, { text: 'Please select one of the options below:' });

                reply.attachments = [card];
                 await stepContext.context.sendActivity(reply); 
                  return await stepContext.prompt('textPrompt', ''); 
        }
            else if(bookingDetails.firstSelection=='Add to exception list') {
    
                     return await stepContext.endDialog();
            }
            //  else if(bookingDetails.firstSelection==="Fetch MH Policy Number for a PINJ Policy Number"){
                
            else if((bookingDetails.firstSelection.localeCompare("Fetch MH Policy Number for a PINJ Policy Number"))==0){
            
                console.log("etch MH Policy Number fo");
                return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please enter **Pin policy number**' });
            }      
    }
    
    async thirdStep(stepContext) {
        const bookingDetails = stepContext.options;
          if((bookingDetails.firstSelection.localeCompare("Fetch MH Policy Number for a PINJ Policy Number"))==0)
          {
             var t;
var jsonobj= [{ PINPOLICYNUMBER: '0005NAP200519300', 
    MHPOLICYNUMBER: '210636.1.01042019' },
  { PINPOLICYNUMBER: '0005NAP200545300',
    MHPOLICYNUMBER: '213530.1.24062019' },
  { PINPOLICYNUMBER: '0005NAP200518800',
    MHPOLICYNUMBER: '210490.1.01042019' },
  { PINPOLICYNUMBER: '0005NAP200522000',
    MHPOLICYNUMBER: '210727.1.01012019' },
  { PINPOLICYNUMBER: '0005NAP200527000',
    MHPOLICYNUMBER: '211515.1.19092018' },
  { PINPOLICYNUMBER: '0005NAP200571100',
    MHPOLICYNUMBER: '218567.1.21082019' }
    ]
    
// let  student= fs.readFileSync(test_json);
// let rawdata = JSON.parse(student);
console.log(jsonobj);
console.log(typeof(jsonobj));
for(var i=0;i<jsonobj.length; i++)
{
                if(jsonobj[i]["PINPOLICYNUMBER"] == stepContext.result)
                {
                                t = jsonobj[i]["MHPOLICYNUMBER"];
                }
}
await stepContext.context.sendActivity("MH Policy Number for a PINJ Policy Number is : " +t);
 return await stepContext.endDialog(bookingDetails);
} 
else
{
    
        // Capture the response to the previous step's prompt
        bookingDetails.secondSelection = stepContext.result;
        // if (bookingDetails.secondSelection=="Line"||"Adjustment") {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please enter the respective **Pin policy number**: ' });
        // } 
 }
     
} 
     
    
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the results of the previous step
        bookingDetails.thirdSelection = stepContext.result;
               
        const Text = [
                     ];


// const card = CardFactory.heroCard('', undefined,
//             Text, { text: 'You hav provided the following details. \n\n**Entity ID** \t\t: '+ bookingDetails.entityID + '\n\n **Editor Name**:\t\t' + bookingDetails.editor_name +'\n\n **Recommended Name**:\t\t'+bookingDetails.recomnded_name_string + '\n\n **Please confirm if this information is correct?**'   });
console.log("checking BOOKINGDETAILS",bookingDetails);
 await stepContext.context.sendActivity("Thanks, this is what you’ve told me:\n\n**Ticket creation on Manhatton**\n**Action on Manhatton**: "+ bookingDetails.firstSelection +'\n **Line**\t'+bookingDetails.secondSelection +"\n**Pin policy number**: "+bookingDetails.thirdSelection);
 
 const card = CardFactory.heroCard('', undefined,
            Text, { text: "Do you want to submit this request?"});            
return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
    
    }
    

    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;

            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

module.exports.manhattan = manhattan;