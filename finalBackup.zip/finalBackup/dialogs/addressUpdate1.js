// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
// const { DateResolverDialog } = require('./dateResolverDialog');
const { CardFactory } = require('botbuilder-core');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const CONFIRM_PROMPT = 'confirmPrompt';
// const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class addressUpdate extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'addressUpdate');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            // .addDialog(new DateResolverDialog(DATE_RESOLVER_DIALOG))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                this.entityConfirm.bind(this),
                 this.addressType.bind(this),
                this.address.bind(this),               
                this.confirmStep.bind(this),         
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    /**
     * If a destination city has not been provided, prompt for one.
     */
    async EntityID(stepContext) {
        const bookingDetails = stepContext.options;
        console.log("Intent name is: ", bookingDetails);        
        console.log("123");
        console.log("123456",bookingDetails);
        if (!bookingDetails.entityID ) {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: "I can help you to request address data be updated on legal entity.\nWhat's the 8 digit Legal Enitity Directory ID" });
            
             
            // var reply = MessageFactory.suggestedActions(['Cancel'], 'I can help you to request address data be updated on legal entity.'+"\n\n What's the 8 digit Legal Enitity Directory ID ");
            // return await stepContext.context.sendActivity(reply);
            // return await stepContext.prompt(TEXT_PROMPT,'Please enter your Entity ID' );
        } 
        else 
        {
           //if entity id is given then fetch entity details and ask for confirmation  
           
            
            return await stepContext.next(bookingDetails.entity_id_value);
        }
    }
    async entityConfirm(stepContext){
        const Text = [
                     ];
                     
                     const card = CardFactory.heroCard('', undefined,
            Text, { text: 'Is this entity you want to update?. \n\n**Entity ID** \t\t: '+ bookingDetails.entityID + '\n\n **Entity Name**:\t\t' + "Acko Technology" + '\n\n **Please confirm if this information is correct?**' + ''  });
                 return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
        
    }
    /**
     * If an origin city has not been provided, prompt for one.
     */
    async addressType(stepContext) {
         
         
         const bookingDetails = stepContext.options;
          console.log('booking details are provied:',bookingDetails);           
       console.log('inside the addresstype:$',stepContext.context.activity);
if (stepContext.context.activity.text=="Yes"){
        // Capture the response to the previous step's prompt
        bookingDetails.entityID = stepContext.result;
        if (!bookingDetails.addressType) {
              const Address_Types = CardFactory.adaptiveCard(AddressTypes);
            return await context.sendActivity({ attachments: [Address_Types] });
            // return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please mention the address type for updation' });
        }
         else {
            
            // const Address_Types = CardFactory.adaptiveCard(AddressTypes);
            // return await context.sendActivity({ attachments: [Address_Types] });
            
            return await stepContext.next(bookingDetails.address_type_value);
        }
    } else if(stepContext.context.activity.text=="No"){
        return EntityID(stepContext)
    }
    }
    
    async address(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the response to the previous step's prompt
        bookingDetails.address_string = stepContext.result;
        if (!bookingDetails.address_string) {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please enter the respective respective address to be updated: ' });
        }
         else {
            //  bookingDetails.editor_name
            return await stepContext.next(bookingDetails.address_value);
            
        }
    }
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;

        // Capture the results of the previous step
        bookingDetails.editor_name = stepContext.result;
        //const msg = `Please confirm, your Entity ID is : ${ bookingDetails.entityID } And you want to update: ${ bookingDetails.editor_name } as: ${ bookingDetails.recomnded_name_string }.`;
        // const msg = 'You hav provided the following details ' + '/r/n' + ' 1234';
        //   const msg1 = '123';
        
        const Text = [
                         //' Please confirm, your Entity ID is \n\n : '+ bookingDetails.entityID + ' And you want to update:\n\n' +                                   bookingDetails.editor_name +'as:\n\n'+bookingDetails.recomnded_name_string  
                     ];

//  const card = CardFactory.heroCard('', undefined,
            // Text, { text: 'Please confirm, your \n\n**Entity ID** \t\t: '+ bookingDetails.entityID + '\n\n **Editor Name**:\t\t' +                bookingDetails.editor_name +'\n\n **Recommended Name**:\t\t'+bookingDetails.recomnded_name_string });

const card = CardFactory.heroCard('', undefined,
            Text, { text: 'You hav provided the following details. \n\n**Entity ID** \t\t: '+ bookingDetails.entityID + '\n\n **Entity Name**:\t\t' + "Acko Technology" +'\n\n **Address Type**:\t\t'+bookingDetails.addressType +'\n\n **Address**:\t\t'+ bookingDetails.address_string+'\n\n **Please confirm if this information is correct?**' + ''  });


return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });

        
        
        
        // const msg = CardFactory.heroCard(
        //     // 'You have entered the following details. ' + '/n/n Entity ID: ' + bookingDetails.entityID + '\n\n Editor category: ' + bookingDetails.editor_name + '\n\n Recommended editor to update: ' + bookingDetails.recomnded_name_string + '/n/n Please confirm if this information is correct?'
        //     'You have entered the following details.' +'n\n Entity ID: ' + bookingDetails.entityID +'\n\n Editor category: ' + bookingDetails.editor_name + '\n\n Recommended editor to update: ' + bookingDetails.recomnded_name_string+ '\n\n Please confirm if this information is correct? ' + ''
        //     );
        // return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [msg] } });    
    }
    

    /**
     * Complete the interaction and end the dialog.
     */
    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;

            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

// module.exports.addressUpdate = addressUpdate;