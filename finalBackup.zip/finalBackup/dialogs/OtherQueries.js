// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { CardFactory } = require('botbuilder-core');
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const OTHER_ENTITY_CHECK = 'OtherQueries_entCheck';
const WATERFALL_DIALOG = 'waterfallDialog';

class OtherQueries extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'OtherQueries');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))           
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				// this.EntityID.bind(this),
                this.DescrptionBlock.bind(this),
                this.confirmStep.bind(this),         
				this.finalStep.bind(this),
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }


 /*async EntityID(stepContext) {
       const bookingDetails = stepContext.options;
             
         if (!bookingDetails.entity_id_value || (bookingDetails.entity_id_value).length != 8) {
             console.log("entity fucntion");
            return await stepContext.beginDialog("OtherQueries_entCheck", {entityID: bookingDetails.entity_id_value });            
         }
         else
         {
             return await stepContext.next(bookingDetails.entity_id_value);
         }
 }*/
 
  async DescrptionBlock(stepContext) {
       const bookingDetails = stepContext.options;
      
       // bookingDetails.descrptn = stepContext.result;       
        await stepContext.context.sendActivity("Please give me a brief description of your query and I’ll raise a ticket for you.");
        return await stepContext.prompt('textPrompt', ''); 
  }
   
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;
        bookingDetails.descrptn = stepContext.result;
        const Text = [
                     ];

      // await stepContext.context.sendActivity("Thanks, this is what you’ve told me:\n\n**Other legal entity queries**\n**Legal Entity ID:** "+ bookingDetails.entityID + "**\n**Description:** " + bookingDetails.descrptn)

      await stepContext.context.sendActivity("OK, I drafted a ticket that says, " + '"' + bookingDetails.descrptn + '"');
      const card = CardFactory.heroCard('', undefined,Text, { text: "Do you want to submit this request?" });


      return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
  
    }
    

    
    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;

            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

module.exports.OtherQueries = OtherQueries;