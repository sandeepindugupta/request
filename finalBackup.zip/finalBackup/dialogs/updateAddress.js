// // Copyright (c) Microsoft Corporation. All rights reserved.
// // Licensed under the MIT License.

// const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
// const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
// const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
// const { DateResolverDialog } = require('./dateResolverDialog');

// const CONFIRM_PROMPT = 'confirmPrompt';
// const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
// const TEXT_PROMPT = 'textPrompt';
// const WATERFALL_DIALOG = 'waterfallDialog';

// class UpdateAddress extends CancelAndHelpDialog {
//     constructor(id) {
//         super(id || 'UpdateAddress');

//         this.addDialog(new TextPrompt(TEXT_PROMPT))
//             .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
//             .addDialog(new DateResolverDialog(DATE_RESOLVER_DIALOG))
//             .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
//                  this.MailingAddress.bind(this),
//                 // this.originStep.bind(this),
//                 // this.travelDateStep.bind(this),
//                 // this.confirmStep.bind(this),
//                 // this.finalStep.bind(this)
// 				// this.EntityID.bind(this),
//                 //  this.RecommededName.bind(this),
//                 // this.Editors.bind(this),               
//                 // this.confirmStep.bind(this),
//                 // this.travelDateStep.bind(this),
				
//             ]));

//         this.initialDialogId = WATERFALL_DIALOG;
//     }

//     /**
//      * If a destination city has not been provided, prompt for one.
//      */
//     async MailingAddress(stepContext) {
//         const bookingDetails = stepContext.options;
//         console.log("Intent name is: ", bookingDetails);
//         //console.log("Intent name of particulars: ", bookingDetails.entity_id);
//         console.log("inside MailingAddress");
//         console.log("123456",bookingDetails.mailing);
//         if (!bookingDetails.mailing ) {
//             // return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please enter your Entity ID' });
//                 return await stepContext.prompt(TEXT_PROMPT,'Please enter your Address' );
//         } 
//         else 
//         {
//             return await stepContext.next(bookingDetails.entity_id_value);
//         }
//     }

//     /**
//      * If an origin city has not been provided, prompt for one.
//      */
//     // async RecommededName(stepContext) {
//     //     const bookingDetails = stepContext.options;

//     //     // Capture the response to the previous step's prompt
//     //     bookingDetails.entityID = stepContext.result;
//     //     if (!bookingDetails.recomnded_name) {
//     //         return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please mention the recommended name for updation' });
//     //     } else {
//     //         return await stepContext.next(bookingDetails.recomnded_name_string);
//     //     }
//     // }
    
//     // async Editors(stepContext) {
//     //     const bookingDetails = stepContext.options;

//     //     // Capture the response to the previous step's prompt
//     //     bookingDetails.recomnded_name_string = stepContext.result;
//     //     if (!bookingDetails.editors) {
//     //         return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please mention the respective editor to be updated: ' });
//     //     } else {
//     //         //  bookingDetails.editor_name
//     //         return await stepContext.next(bookingDetails.editor_name);
            
//     //     }
//     // }
// // editor_name
//     /**
//      * If a travel date has not been provided, prompt for one.
//      * This will use the DATE_RESOLVER_DIALOG.
//      */
//     // async travelDateStep(stepContext) {
//     //     const bookingDetails = stepContext.options;

//     //     // Capture the results of the previous step
//     //     bookingDetails.origin = stepContext.result;
//     //     if (!bookingDetails.travelDate || this.isAmbiguous(bookingDetails.travelDate)) {
//     //         return await stepContext.beginDialog(DATE_RESOLVER_DIALOG, { date: bookingDetails.travelDate });
//     //     } else {
//     //         return await stepContext.next(bookingDetails.travelDate);
//     //     }
//     // }

//     /**
//      * Confirm the information the user has provided.
//      */
//     // async confirmStep(stepContext) {
//     //     const bookingDetails = stepContext.options;

//     //     // Capture the results of the previous step
//     //     bookingDetails.editor_name = stepContext.result;
//     //     const msg = `Please confirm, your Entity ID is : ${ bookingDetails.entityID } And you want to update: ${ bookingDetails.editor_name } as: ${ bookingDetails.recomnded_name_string }.`;

//     //     // Offer a YES/NO prompt.
//     //     return await stepContext.prompt(CONFIRM_PROMPT, { prompt: msg });
//     // }
    

//     /**
//      * Complete the interaction and end the dialog.
//      */
//     // async finalStep(stepContext) {
//     //     console.log("final step is : ",stepContext.result);
//     //     if (stepContext.result === true) {
//     //         const bookingDetails = stepContext.options;

//     //         return await stepContext.endDialog(bookingDetails);
//     //     } else {
//     //         return await stepContext.endDialog();
//     //     }
//     // }

//     // isAmbiguous(timex) {
//     //     const timexPropery = new TimexProperty(timex);
//     //     return !timexPropery.types.has('definite');
//     // }
// }

// module.exports.UpdateAddress = UpdateAddress;




const { CardFactory } = require('botbuilder-core');
const Card = require('./AdaptiveCards/AddressTypes.json');
//const {TextPrompt} = require('botbuilder-dialogs');
const TEXT_PROMPT = 'textPrompt';
class UpdateAddress {
     static async executeUpdateAddress(logger, context){
         
          const bookingDetails1 = {};
          
          
                //var activitytext = JSON.stringify(context.activity.value.type);
                //this.addDialog(new TextPrompt(TEXT_PROMPT));
                 return; await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please enter your Entity ID' });
                     console.log("ppppaaaaaaaaaaaapppp");
                    
                    // console.log(stepContext.context.activity);
      //                var curr_add=context.activity.value.current;
      //                var per_add=context.activity.value.comment;
      //                var mail_address=context.activity.value.mailing;
      //    if(curr_add)    {
      //          return await context.sendActivity(`You have updated your Current address ${context.activity.value.current}`);
      //    }     else if (per_add)
      //    {
      //         return  await context.sendActivity(`You have updated your Permanant address ${context.activity.value.Permanant}`);
      //    }   else if (mail_address) {
      //         return  await context.sendActivity(`You have updated your mailing address ${context.activity.value.mailing}`); 
      //    }else{
      //           return bookingDetails1;
      //    }
                   
                     
     // }
   


    
}
}


module.exports.UpdateAddress = UpdateAddress;