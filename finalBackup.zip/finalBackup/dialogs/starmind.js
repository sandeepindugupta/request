 const {AttachmentLayoutTypes,ActionTypes,ActivityTypes,MessageFactory,ActivityHandler,TurnContext} = require('botbuilder');
const { ChoicePrompt, ListStyle,ConfirmPrompt, TextPrompt,NumberPrompt,ComponentDialog, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { Entity_ID_check } = require('./Entity_ID_check');
var request = require("request-promise");


const { CardFactory } = require('botbuilder-core');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const ENTITYIDCHECK = 'Entity_ID_check';
const WATERFALL_DIALOG = 'waterfallDialog';
const NUMBER_PROMPT='numberprompt';
const CARD_PROMPT='cardPrompt';
const CHOICE_PROMPT = 'CHOICE_PROMPT';



class starmind extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'starmind');
        
        this.addDialog(new TextPrompt(TEXT_PROMPT))
            // .addDialog(productsPrompt)
            .addDialog(new ChoicePrompt('cardPrompt'))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))
            .addDialog(new Entity_ID_check(ENTITYIDCHECK))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.FAQquery.bind(this),
                 this.APIResolve.bind(this),
                this.queryQuestionResponse.bind(this),
                this.queryQuestionId.bind(this),
                this.answerResponse.bind(this),            
                this.confirmStep.bind(this),
                 this.yesorno.bind(this), 
                this.finalStep.bind(this)       
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

   
    
    async FAQquery(stepContext) {
    
        
        
        const bookingDetails = stepContext.options;
        
        return await stepContext.prompt('textPrompt', 'Please enter your FAQ related to LEM/Englobe.'); 
    }
    
    
    
    async APIResolve(stepContext) {
        
  	 
        var bookingDetails = stepContext.options;
        console.log("sandy",bookingDetails);
        const queryStarmind= stepContext.result;    
        // console.log("accepting input from user",bookingDetails);
        console.log("checking  result",stepContext.result);
        
     var responseOne='';
     var responseTwo='';
var responseRes=await firstFun(stepContext);
return await stepContext.next(responseRes);
async function firstFun(stepContext)
{
    try{
        console.log("inside first fxn")
        responseOne= await tokenFxn();
        responseTwo= await starmindResponse(responseOne);
    if(responseTwo!=null){
        //  return await stepContext.next(responseTwo);
        return responseTwo;
 
  }
    }catch(error){
        console.log(error);
    }
}

async function tokenFxn()
 {
   return await new Promise(function (resolve, reject)
{
       var options = { method: 'POST',
 url: 'https://swissre.starmind.com/api/v1/auth/login',
 headers:
  { 'postman-token': '7d1925f6-35fc-20b0-60aa-ef9d7658a64f',
    'cache-control': 'no-cache',
    'x-auth-apikey': 'kjhb2342398z423hjvx234xjhnkjoiuo34',
    accept: 'application/json',
    'content-type': 'application/json' },
 body:
  { email: 'TECDRRT1_Service@swissre.com',
    password: 'poiu234nklklj2469lkj' },
 json: true };

request(options, function (error, response, body) {

 if (!error) {
    //  stepContext.token=body.token;
               resolve(body.token);
           } else {
               reject(error);
           }

});

});
}


async function starmindResponse(responseOne){
return await new Promise(function (resolve, reject)
{
   // var token=stepContext;
   var auth= "Bearer "+responseOne;
   console.log("token",auth);

var options = { method: 'GET',
 url: 'https://swissre.starmind.com/api/v1/questions',
 qs: { query: queryStarmind },
 headers:
  { 'postman-token': 'bcb29682-dbec-93db-2c1e-1679a3129dca',
    'cache-control': 'no-cache',
    authorization: auth,
    'content-type': 'application/json',
    'x-auth-apikey': 'kjhb2342398z423hjvx234xjhnkjoiuo34' } };



request(options, function (error, response, body) {

if (error) throw new Error(error);

 var respo=JSON.parse(body);

resolve(respo);
 

});
});
}

    
    }
     

 
   
    async queryQuestionResponse(stepContext) {
        const bookingDetails = stepContext.options;
        // console.log("options ##",stepContext);
        bookingDetails.query=stepContext.result
        // console.log("length of starmind title",stepContext.result.items.length);
         console.log("total of starmind",stepContext.result.total);
        // console.log("after entity id check123",stepContext.result.items[0].id);
        console.log("bookingdetails sandeep",bookingDetails);
    // var heading=stepContext.result.items[0].title;
    
    
  
             if(stepContext.result.total>=9){
                  var card1= {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [
        {
            "type": "TextBlock",
            "text": "I found some FAQ’s on Starmind that might help:",
            "wrap": true,
            "weight": "Bolder"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[0].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data":stepContext.result.items[0].title
              // "value":stepContext.result.items[0].id
              // "title": "Mailing"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[1].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[1].title,
              "title": "Business"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[2].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[2].title,
              "title": "Registered"
            },
            "height": "auto"
        }
        
         
        
    ]
}
var card2= {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [
        {
            "type": "TextBlock",
            "text": "I found some FAQ’s on Starmind that might help:",
            "wrap": true,
            "weight": "Bolder"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[3].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data":stepContext.result.items[3].title,
              "title": "Mailing"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[4].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[4].title,
              "title": "Business"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[5].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[5].title,
              "title": "Registered"
            },
            "height": "auto"
        }
        
         
        
    ]
}
var card3= {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [
        {
            "type": "TextBlock",
            "text": "I found some FAQ’s on Starmind that might help:",
            "wrap": true,
            "weight": "Bolder"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[6].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data":stepContext.result.items[6].title,
              "title": "Mailing"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[7].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[7].title,
              "title": "Business"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[8].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[8].title,
              "title": "Registered"
            },
            "height": "auto"
        }
        
         
        
    ]
}

               const Types1 = CardFactory.adaptiveCard(card1);
               const Types2 = CardFactory.adaptiveCard(card2);
               const Types3 = CardFactory.adaptiveCard(card3);
                await stepContext.context.sendActivity({attachments: [Types1,Types2,Types3], attachmentLayout: AttachmentLayoutTypes.Carousel});
               return await stepContext.prompt('textPrompt', '');
             }
             else if(stepContext.result.total==0 ||stepContext.result.total<0|| stepContext.result.total<9){
                 return await stepContext.context.sendActivity("I can�t find any information on this, give me another chance and ask in a different way (simple sentences work best).");
             }
        
       
    }

    //*******************************************************************

async queryQuestionId(stepContext) {
        
     
        var bookingDetails = stepContext.options;
        // console.log("sandy",bookingDetails);
        const query= stepContext.result;    
        // console.log("accepting input from user",bookingDetails);
        console.log("query in id  result",stepContext.result);
        
     var responseOne='';
     var responseTwo='';
var responseRes=await firstFun(stepContext);
// console.log("response in queryid",responseRes);
var i;
  for( i=0;i<=responseRes.items.length;i++){
    if(stepContext.result==responseRes.items[i].title){
        return await stepContext.next(responseRes.items[i].id+" "+stepContext.result);
    }
  }


// return await stepContext.next(responseRes);



async function firstFun(stepContext)
{
    try{
        console.log("inside first fxn")
        responseOne= await tokenFxn();
        responseTwo= await starmindResponse(responseOne);
    if(responseTwo!=null){
        //  return await stepContext.next(responseTwo);
        return responseTwo;
 
  }
    }catch(error){
        console.log(error);
    }
}

async function tokenFxn()
 {
   return await new Promise(function (resolve, reject)
{
       var options = { method: 'POST',
 url: 'https://swissre.starmind.com/api/v1/auth/login',
 headers:
  { 'postman-token': '7d1925f6-35fc-20b0-60aa-ef9d7658a64f',
    'cache-control': 'no-cache',
    'x-auth-apikey': 'kjhb2342398z423hjvx234xjhnkjoiuo34',
    accept: 'application/json',
    'content-type': 'application/json' },
 body:
  { email: 'TECDRRT1_Service@swissre.com',
    password: 'poiu234nklklj2469lkj' },
 json: true };

request(options, function (error, response, body) {

 if (!error) {
    //  stepContext.token=body.token;
               resolve(body.token);
           } else {
               reject(error);
           }

});

});
}


async function starmindResponse(responseOne){
return await new Promise(function (resolve, reject)
{
   // var token=stepContext;
   var auth= "Bearer "+responseOne;
   console.log("token",auth);

var options = { method: 'GET',
 url: 'https://swissre.starmind.com/api/v1/questions',
 qs: { query: query },
 headers:
  { 'postman-token': 'bcb29682-dbec-93db-2c1e-1679a3129dca',
    'cache-control': 'no-cache',
    authorization: auth,
    'content-type': 'application/json',
    'x-auth-apikey': 'kjhb2342398z423hjvx234xjhnkjoiuo34' } };



request(options, function (error, response, body) {

if (error) throw new Error(error);

 var respo=JSON.parse(body);

 
resolve(respo);
 

});
});
}

    
    }


    //*********************************************************************
async answerResponse(stepContext){
      var str=stepContext.result;
      console.log("idis",str);
        var idis=str.substr(0,str.indexOf(' '));
      
        var ques=str.substr(str.indexOf(' ')+1);
 var responseOne='';
     var responseTwo='';
var responseRes=await firstFun(stepContext);

// console.log("Answer is",responseRes.solutions);
if(responseRes.solution_count>0) //
{
  console.log("responseRes.solution_count",typeof(responseRes.solution_count));
if (responseRes.solution_count!=null && responseRes.solution_count==1)
{
  console.log("inside count 1");
     await stepContext.context.sendActivity(`**${ques}**`+"\n\n"+responseRes.solutions[0].description);
    return await stepContext.next(stepContext);
}
else if(responseRes.solution_count>1) //
{
    var value = [];
    for (var i=0;i<responseRes.solutions.length;i++){
        console.log("responseRes.solutions.length",responseRes.solutions.length);
        // console.log("length",responseRes.solutions[i]["rating"]);
      value.push(responseRes.solutions[i]["rating"]);
      // console.log("value",value);
    }
      value.sort();
      value.reverse();
     var  maxvalue=value[0];
      
      // console.log("maxvalue",maxvalue);
      
      for(var i=0;i<responseRes.solutions.length;i++){
       if(maxvalue==responseRes.solutions[i]["rating"])
       {
            await stepContext.context.sendActivity(`**${ques}**`+"\n\n"+responseRes.solutions[i].description);
           return await stepContext.next(stepContext);
       }
       
      }   
    }
}
else if(responseRes.solution_count==0)
     {
         await stepContext.context.sendActivity(`**${ques}**`+"\n\n"+responseRes.comments[0].description);
         return await stepContext.next(stepContext);
    }
    // else{
    //   return await stepContext.context.sendActivity(`**${ques}**`+"\n\n"+responseRes.description);  
    // }



async function firstFun(stepContext)
{
    try{
        console.log("inside first fxn")
        responseOne= await tokenFxn();
        responseTwo= await starmindQuestionResponse(responseOne);
    if(responseTwo!=null){
        //  return await stepContext.next(responseTwo);
        return responseTwo;
 
  }
    }catch(error){
        console.log(error);
    }
}

async function tokenFxn()
 {
   return await new Promise(function (resolve, reject)
{
       var options = { method: 'POST',
 url: 'https://swissre.starmind.com/api/v1/auth/login',
 headers:
  { 'postman-token': '7d1925f6-35fc-20b0-60aa-ef9d7658a64f',
    'cache-control': 'no-cache',
    'x-auth-apikey': 'kjhb2342398z423hjvx234xjhnkjoiuo34',
    accept: 'application/json',
    'content-type': 'application/json' },
 body:
  { email: 'TECDRRT1_Service@swissre.com',
    password: 'poiu234nklklj2469lkj' },
 json: true };

request(options, function (error, response, body) {

 if (!error) {
    //  stepContext.token=body.token;
               resolve(body.token);
           } else {
               reject(error);
           }

});

});
}


async function starmindQuestionResponse(responseOne){
return await new Promise(function (resolve, reject)
{
   // var token=stepContext;
   var auth= "Bearer "+responseOne;
   console.log("token",auth);
   var urlSandeep="https://swissre.starmind.com/api/v1/questions/"+idis+"/complete";
  console.log("url",urlSandeep);
var options = { method: 'GET',
  url: urlSandeep,
  headers: 
   { 'postman-token': 'b15d24e9-e06c-8da5-d882-908cec7cbf5f',
     'cache-control': 'no-cache',
     authorization: auth,
     'x-auth-apikey': 'kjhb2342398z423hjvx234xjhnkjoiuo34',
     'content-type': 'application/json' } };


request(options, function (error, response, body) {
  if (error) throw new Error(error);

var respo=JSON.parse(body);
  // console.log(body);
  resolve(respo);
});

});
}


    }
       async confirmStep(stepContext){
        var result=stepContext;
        console.log("inside confirm step of starmind",result);
       const Text=[];
        const card = CardFactory.heroCard('', undefined,
            Text, { text: "Was this helpful?"});
     
             
 return await stepContext.prompt(CONFIRM_PROMPT, {prompt: { attachments: [card] } });
       }
       async yesorno(stepContext){
        var selection=stepContext;
        // console.log("selection111",stepContext);
        // console.log("selection22222",stepContext.result);
        // var yesCondition=stepContext.result+stepContext.options.intent;
        // console.log("selection",yesCondition);
        if(stepContext.result==true){
           await stepContext.context.sendActivity("Pleased I could help!");
           
                    return await stepContext.endDialog(stepContext);

        }else{
          console.log("no condition");
            const promptMessage=MessageFactory.suggestedActions(['Cancel'],"Give me a description of your inquiry and I’ll raise a ticket for you.");
        await stepContext.context.sendActivity(promptMessage);
        return await stepContext.prompt('textPrompt', '');
        }
       }
   
     async finalStep(stepContext) {
       
       // console.log("final step in starmind",stepContext);
       // console.log("final ",stepContext.options);
        const bookingDetails = stepContext;
        if (stepContext!=null) {
            // const bookingDetails = stepContext.options;
            console.log("inside final step of address ",bookingDetails);
            return await stepContext.endDialog(bookingDetails);
        }
        return await stepContext.endDialog();
    }
    
}

module.exports.starmind = starmind;