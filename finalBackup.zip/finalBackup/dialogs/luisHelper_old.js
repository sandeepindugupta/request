// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { LuisRecognizer } = require('botbuilder-ai');
const { CardFactory } = require('botbuilder-core');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const { QnAMaker } = require('botbuilder-ai');
const EditorList = require('./AdaptiveCards/EditorList.json');
const Update_AFT = require('./AdaptiveCards/update_AFT.json');
const newWelcome=require('./AdaptiveCards/Lem_NewWelcome.json');
const Tax = require('./AdaptiveCards/tax.json');
const finance_card = require('./AdaptiveCards/financeData.json');
const workflowTypeCard = require('./AdaptiveCards/Workflow_queries_types.json');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { ChoiceFactory } = require('botbuilder-choices');

class LuisHelper extends CancelAndHelpDialog {
    /**
     * Returns an object with preformatted LUIS results for the bot's dialogs to consume.
     * @param {*} logger
     * @param {TurnContext} context
     */
    static async executeLuisQuery(logger, context) {    const bookingDetails = {};

    try {
        const recognizer = new LuisRecognizer({
            applicationId: process.env.LuisAppId,
            endpointKey: process.env.LuisAPIKey,
            endpoint: `https://${ process.env.LuisAPIHostName }`
        }, {}, true);

        const recognizerResult = await recognizer.recognize(context);

        const intent = LuisRecognizer.topIntent(recognizerResult);
        console.log("recognizerResult ", recognizerResult);
        console.log("Intent is ::::::: flow 5", intent);
        bookingDetails.intent = intent;
        var intentScore;
        if (recognizerResult.text != '') {
            intentScore = recognizerResult.luisResult.topScoringIntent.score;
        }

        console.log("score value::", intentScore);

/*console.log("knowledge : ", process.env.QnAKnowledgebaseId);
        const QnA_recognizer = {
            knowledgebaseID: process.env.QnAKnowledgebaseId,
            endpointHostName: process.env.QnAEndPointHostName,
            authKey: process.env.QNAAuthKey
        };
        console.log("Qna rec value is: ", QnA_recognizer);
        var qna_answer = new QnAMaker(QnA_recognizer, {});
        console.log("qna_answer is: ", qna_answer);
        const qnaResults = await qna_answer.getAnswers(context);

        console.log("qnaResults is: ", qnaResults);
                  
        // If an answer was received from QnA Maker, send the answer back to the user.
        if (qnaResults[0]) {
            await context.sendActivity(qnaResults[0].answer);
        }*/


        if (intentScore != null && intentScore > 0.50) { //condition to check for threshold
            
            if (intent === 'LEM_Queries') {
              const LEM_welcomeCard = CardFactory.adaptiveCard(newWelcome);
                // LEM_welcomeCard.contentType = 'application/vnd.microsoft.card.custom';
                // console.log('check', context.activity);
                await context.sendActivity({ attachments: [LEM_welcomeCard] });
               
              // await context.sendActivity({attachments: [card]});
               var json={
                        
                             "action": "handover"
                   }
                    var json1=JSON.stringify(json);
         await context.sendActivity(json1);
                            
                 var reply = MessageFactory.suggestedActions(['Cancel']);
                 
                  await context.sendActivity(reply);
         /*   const reply = { type: ActivityTypes.Event };
            reply.name = 'Trigger_API';           
           console.log("check the reply", reply);
          return await context.sendActivity(reply);*/
                  
                 
               
                               
                console.log('check', context.activity);
                return bookingDetails;
            } else if (intent === "Entity_data_updation") {
                const UpdateAFT = CardFactory.adaptiveCard(Update_AFT);
                await context.sendActivity({ attachments: [UpdateAFT] });
                console.log('check UpdateAFT', context.activity);
                return bookingDetails;
            }
            
            else if (intent === 'EntityEditorsUpdate') {
                const entity_data = recognizerResult.luisResult.entities;
                console.log("Entity complete data  is ", entity_data);
                console.log("length of Entity is", entity_data.length);
                if (entity_data.length == 0) {
                     return await context.beginDialog("EntityEditorsUpdate", bookingDetails);
                }
                else {
                    for (var i = 0; i < entity_data.length; i++) {
                        if (entity_data[i].type == "Entity_ID") {
                            bookingDetails.entityID = entity_data[i].type;
                            bookingDetails.entity_id_value = entity_data[i].entity;
                            console.log("Inside ENTITY", bookingDetails.entityID);
                        }
                        else if (entity_data[i].type == "editor_entities_list") {
                            bookingDetails.editorType = entity_data[i].type;
                            bookingDetails.editorType_value = entity_data[i].entity;
                            console.log("Inside recommend editor", bookingDetails.recomnded_name);
                        }
                        else if (entity_data[i].type == "recommended_name") {
                            bookingDetails.editorName = entity_data[i].type;
                            bookingDetails.editorName_value = entity_data[i].entity;
                            console.log("Inside editor", entity_data[i].entity);
                            break;
                        }


                    }
                }
                return bookingDetails;
            }
            
         //**************Auxiliary operations******************
         else if (intent== "Auxiliary_operations"){
             return bookingDetails;
             
         }
           else if (intent== "Open_ticket_for_all_other_legal_entity_queries"){
               
             return bookingDetails;
             
         }  
        //********CMS Updation**************
        
          else if (intent === 'Entity_CMS') {
                const entity_data = recognizerResult.luisResult.entities;
                console.log("Entity complete data in CMS$$ is ", entity_data);
                console.log("length of Entity is", entity_data.length);
                if (entity_data.length == 0) {
                    return bookingDetails;
                }
                else {
                    for (var i = 0; i < entity_data.length; i++) {
                        if (entity_data[i].type == "Entity_ID") {
                            bookingDetails.entityID = entity_data[i].type;
                            bookingDetails.entity_id_value = entity_data[i].entity;
                            console.log("Inside ENTITY", bookingDetails.entityID);
                             break;
                        }
                        
                       


                    }
                }
                return bookingDetails;
            }
            
        //***********************************    
            
            
            
             else if (intent === 'Entity_address') {
                const entity_data = recognizerResult.luisResult.entities;
                console.log("address check :",recognizerResult.luisResult.entities)
                console.log("Entity complete data  is ", entity_data);
                console.log("length of Entity is", entity_data.length);
                if (entity_data.length == 0) {
                    console.log("CHECKaEntity_address", entity_data.length);
                     console.log("booking check in luisHELPER%%%%%",bookingDetails);
                    return await context.beginDialog("addressUpdate", bookingDetails);

                }
                else {
                    for (var i = 0; i < entity_data.length; i++) {
                        if (entity_data[i].type == "Entity_ID") {
                            bookingDetails.entityID = entity_data[i].type;
                            
                            bookingDetails.entity_id_value = entity_data[i].entity;
                            console.log("Inside ENTITY", bookingDetails.entityID);
                            
                        }
                        else if (entity_data[i].type == "addressType") {
                            console.log("Addresstype:#");
                            bookingDetails.addressType = entity_data[i].entity;
                            bookingDetails.address_type_value = entity_data[i].entity;
                            
                            console.log("Inside address type editor",bookingDetails.address_type_value);
                        }
                        else if (entity_data[i].type == "address") {
                            bookingDetails.address = entity_data[i].type;
                            bookingDetails.address_value = entity_data[i].entity;
                            console.log("Inside address**", entity_data[i].entity);
                            break;
                        }                         

                    }
                }
                return bookingDetails;
            }
            
            
            
            
            
            
            
        


//**************************************WORKFLOW DATA***************************


 else if (intent === 'Workflow_queries') {
                const entity_data = recognizerResult.luisResult.entities;
                console.log("workflow check :",recognizerResult.luisResult.entities)
                console.log("Entity complete data  is ", entity_data);
                console.log("length of Entity is", entity_data.length);
                if (entity_data.length == 0) {
                    console.log("CHECKaEntity_address", entity_data.length);
                   return await context.beginDialog("workflowDataUpdate", bookingDetails);

                }
                else {
                    for (var i = 0; i < entity_data.length; i++) {
                        if (entity_data[i].type == "Entity_ID") {
                            bookingDetails.entityID = entity_data[i].type;
                            
                            bookingDetails.entity_id_value = entity_data[i].entity;
                            console.log("Inside ENTITY", bookingDetails.entityID);
                            
                        }
                        else if (entity_data[i].type == "workflowType") {
                            console.log("Addresstype:#");
                            bookingDetails.workflowType = entity_data[i].entity;
                            bookingDetails.workflow_type_value = entity_data[i].entity;
                            
                            console.log("Inside finance type AAAAAAAAA",entity_data[i].entity);
                        }
                        else if (entity_data[i].type == "workflowDetails") {
                            bookingDetails.workflowDetails = entity_data[i].type;
                            bookingDetails.workflowDetails_value = entity_data[i].entity;
                            console.log("Inside address**", entity_data[i].entity);
                            break;
                        }


                    }
                }
                return bookingDetails;
            }




           
//****************************Finance Details*********************************

  else if (intent === 'Entity_finance') {
                const entity_data = recognizerResult.luisResult.entities;
                console.log("finance check :",recognizerResult.luisResult.entities)
                console.log("Entity complete data  is ", entity_data);
                console.log("length of Entity is", entity_data.length);
                if (entity_data.length == 0) {
                    console.log("CHECKaEntity_address", entity_data.length);
                    return await context.beginDialog("financeDataUpdate", bookingDetails);

                }
                else {
                    for (var i = 0; i < entity_data.length; i++) {
                        if (entity_data[i].type == "Entity_ID") {
                            bookingDetails.entityID = entity_data[i].type;
                            
                            bookingDetails.entity_id_value = entity_data[i].entity;
                            console.log("Inside ENTITY", bookingDetails.entityID);
                            
                        }
                        else if (entity_data[i].type == "financeType") {
                            console.log("Addresstype:#");
                            bookingDetails.financeType = entity_data[i].entity;
                            bookingDetails.finance_type_value = entity_data[i].entity;
                            
                            console.log("Inside finance type AAAAAAAAA",bookingDetails.address_type_value);
                        }
                        else if (entity_data[i].type == "financeDetails") {
                            bookingDetails.financeDetails = entity_data[i].type;
                            bookingDetails.financeDetails_value = entity_data[i].entity;
                            console.log("Inside address**", entity_data[i].entity);
                            break;
                        }


                    }
                }
                return bookingDetails;
            }


//**************************END*********************************************

           

            //    else if (intent === 'Other_LEM/LPE_data_issue') {
            //     // if (context.activity.text == "Update/Maintain LE data") {
            //     //     console.log("inside Update/Maintain LE data");
            //     const otherlpe = CardFactory.adaptiveCard(otherLPE_LEM);
            //     await context.sendActivity({ attachments: [otherlpe] });

            //     //}
            //     return bookingDetails;
            // }

            // else if (intent === 'Update_LE_data') {
            //     // if (context.activity.text == "Update/Maintain LE data") {
            //     //     console.log("inside Update/Maintain LE data");
            //     const Update_AFTR = CardFactory.adaptiveCard(Update_AFT);
            //     await context.sendActivity({ attachments: [Update_AFTR] });

            //     //}
            //     return bookingDetails;
            // }
            //  else if (intent === 'Entity_CMS') {

            //     const api_input_details = CardFactory.adaptiveCard(entityid_card);
            //     await context.sendActivity({ attachments: [api_input_details] });

            //     console.log("inside Check/Update CMS number");
            //     return bookingDetails;

            // }
            
     //********************************TAX DATA************************
     
     else if (intent === 'tax_data') {
                const entity_data = recognizerResult.luisResult.entities;
                console.log("TAX check :",recognizerResult.luisResult.entities)
                console.log("Entity complete data  is ", entity_data);
                console.log("length of Entity is", entity_data.length);
                if (entity_data.length == 0) {
                    console.log("CHECKaEntity_address", entity_data.length);
                    return await context.beginDialog("taxDataUpdate", bookingDetails);

                }
                else {
                    for (var i = 0; i < entity_data.length; i++) {
                        if (entity_data[i].type == "Entity_ID") {
                            bookingDetails.entityID = entity_data[i].type;
                            
                            bookingDetails.entity_id_value = entity_data[i].entity;
                            console.log("Inside ENTITY", bookingDetails.entityID);
                            
                        }
                        else if (entity_data[i].type == "taxType") {
                            console.log("Addresstype:#");
                            bookingDetails.taxType = entity_data[i].entity;
                            bookingDetails.tax_type_value = entity_data[i].entity;
                            
                            console.log("Inside finance type AAAAAAAAA",bookingDetails.address_type_value);
                        }
                        else if (entity_data[i].type == "taxDetails") {
                            bookingDetails.taxDetails = entity_data[i].type;
                            bookingDetails.taxDetails_value = entity_data[i].entity;
                            console.log("Inside address**", entity_data[i].entity);
                            break;
                        }


                    }
                }
                return bookingDetails;
            }
     
     //******************************************************************
          
           
           
            else if (intent === 'None') {
                return bookingDetails;
            }
            else if (intent === 'general_queries') {
                console.log("inside general_queries");
                const general_queries1 = CardFactory.adaptiveCard(general_queries);
                await context.sendActivity({ attachments: [general_queries1] });
                return bookingDetails;
            }
        }//score if ends here
   else if (intentScore != null && intentScore < 0.50) {      
       // await context.sendActivity("I’m sorry, I don’t understand the question. Could you please try rephrasing it so that I can better assist you? I want to help.. ");
               bookingDetails.intent = "None";               
                return bookingDetails;
            }
        
    } catch (err) {
        logger.warn(`LUIS Exception: ${ err } Check your LUIS configuration`);
    }
    return bookingDetails;
}


}

module.exports.LuisHelper = LuisHelper;