// // Copyright (c) Microsoft Corporation. All rights reserved.
// // Licensed under the MIT License.
const { CardFactory } = require('botbuilder-core');
const Card = require('./AdaptiveCards/AddressTypes.json');
//const {TextPrompt} = require('botbuilder-dialogs');
const TEXT_PROMPT = 'textPrompt';
class APICall {
    static async executeAPIcall(logger, stepContext){
        console.log("asdfdsstepContext value is ", stepContext.activity.value.entityId);
     let Api_input_values = {};     
      Api_input_values.entityId = stepContext.activity.value.entityId;
      Api_input_values.entityName = stepContext.activity.value.entityName;
      // Api_input_values.comment=stepContext.activity.value.comment;
    console.log("APICall",Api_input_values);
    console.log("APICall",stepContext.context.activity.value);
     return await stepContext.sendActivity(`You said EntityID:${stepContext.activity.value.entityId} \n Entity Name:${stepContext.activity.value.entityName}`);
    // await stepContext.endDialog();


}
}

module.exports.APICall = APICall;