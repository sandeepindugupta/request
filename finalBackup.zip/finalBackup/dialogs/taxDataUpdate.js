// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ConfirmPrompt, TextPrompt,NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { CardFactory } = require('botbuilder-core');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const finance_card = require('./AdaptiveCards/financeData.json');
const Tax = require('./AdaptiveCards/tax.json');
const { Entity_ID_check } = require('./Entity_ID_check');
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';
const NUMBER_PROMPT='numberprompt';
const ENTITYIDCHECK = 'Entity_ID_check';
class taxDataUpdate extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'taxDataUpdate');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))
            .addDialog(new Entity_ID_check(ENTITYIDCHECK))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                 this.taxType.bind(this),
                this.taxDetails.bind(this),               
                this.confirmStep.bind(this), 
                this.finalStep.bind(this)        
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    async EntityID(stepContext) {
           const bookingDetails = stepContext.options;
        
        const Intent_ent_json = { "intent_value" : "tax data",
            "entity_id_value":  bookingDetails.entity_id_value
            
        }        
         if (!bookingDetails.entity_id_value || (bookingDetails.entity_id_value).length != 8) {
             console.log("entity fucntion");
            return await stepContext.beginDialog("Entity_ID_check", Intent_ent_json);
            
         }
         else
         {
             return await stepContext.next(bookingDetails.entity_id_value);
         }
    }
    
    
    async taxType(stepContext) {
        const bookingDetails = stepContext.options;
        console.log("financeTypeEEEEE functiom:@",stepContext.options);
        if(stepContext.result.toString().length != 8)
            {
                return await stepContext.endDialog();
            }
        bookingDetails.entityID = stepContext.result;
        console.log("Step contxet****",stepContext.result);
        if (!bookingDetails.taxType) {
            console.log("insideTTTTT types");
             const taxCard = CardFactory.adaptiveCard(Tax);
          await stepContext.context.sendActivity({attachments: [taxCard] });
           return await stepContext.prompt('textPrompt', '');





        } 
    
        else {
            return await stepContext.next(bookingDetails.tax_type_value);
        }
        
    }
    
    async taxDetails(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.tax_type_value = stepContext.result.toLowerCase();
        
         var  newtaxType;
        if (bookingDetails.tax_type_value.startsWith ("update"))
        {
            console.log("newAddressType", stepContext.result.toLowerCase());
             newtaxType=bookingDetails.tax_type_value.slice(7,);
        }
        else
        {
            newtaxType=bookingDetails.tax_type_value;
        }
        
        console.log("stepContext.result in address$$",stepContext.result);
        if (!bookingDetails.taxDetails) {
            // return await stepContext.prompt(TEXT_PROMPT, { prompt: 'What’s the correct '+`**${newtaxType}**` +" **data**"+' ? \nPlease type or paste it in full.' });
          return await stepContext.prompt(TEXT_PROMPT, { prompt: "Please enter the "+`**${newtaxType}**`+' field/s need to update, with its respective details' 
+' ? \nPlease type or paste it in full.' });
        } else {
            return await stepContext.next(bookingDetails.taxDetails_value);
            
        }
    }
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.taxDetails = stepContext.result;
        
          var  newTaxType;
        if (bookingDetails.tax_type_value.toLowerCase().startsWith ("update"))
        {
            
             newTaxType=bookingDetails.tax_type_value.slice(7,);
        }
        else
        {
            newTaxType=bookingDetails.tax_type_value;
        }
        
        const Text = [
                     ];


await stepContext.context.sendActivity("Thanks, this is what you’ve told me:\n\n**Updated tax data**\n**Entity ID**: "+ bookingDetails.entityID +'\n **New**\t'+`**${newTaxType}**` +" **data**"+":\t\t"+ bookingDetails.taxDetails);
const card = CardFactory.heroCard('', undefined,
            Text, { text:"Do you want to submit this request?"});

return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
    
    }
    

    
    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;

            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

module.exports.taxDataUpdate = taxDataUpdate;