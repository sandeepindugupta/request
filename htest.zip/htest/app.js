const express = require('express');
var bodyParser = require('body-parser');
var request = require("request");
var url = require('url');
const fs = require('fs');
const superagent = require('superagent');
var port = Number(process.env.PORT || 3000);
const app = express();

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use(bodyParser.json()); // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({ // to support URL-encoded bodies
  extended: true
}));



app.post('/swissreAPICALL', function(req, res) {
  // console.log(req.body.ebody.slice(0,50));
  res.header("Content-Type", "application/json");
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods', 'POST');
  return new Promise((resolve, reject) => {
  superagent
  	.post('https://lem-dev.swissre.com/ids/connect/token')
  	.send({ grant_type: 'password',
       		username: 'TECDRRT1',
       		password: 'Chatbot_dev',
       		scope: 'openid xtekUser offline_access',
       		client_id: 'xtekLocal',
       		client_secret: '4tFTxc0u0LZvYjky8imx' })

  	.set ('cache-control', 'no-cache')
       	.set('connection', 'keep-alive')
      	.set('content-length', '154')
       	.set('accept-encoding', 'gzip, deflate')
       	.set('Host' ,'lem-dev.swissre.com')
       	.set('Postman-Token', 'dd2006f9-479b-4645-ae76-ed1142ff26e2,78739d7a-a3b1-4faa-8d46-d31f698746c8')
       	.set('User-Agent'. 'PostmanRuntime/7.11.0')
       	.set('accept', 'application/json')
       	.set('Content-Type','application/x-www-form-urlencoded')
  	 }


        .end((err, res) => {
          if (err) {
            console.log(`Error: ${err.name}-${err.message}`)
            return reject(err)
          }
          console.log(`Resolve: ${res.text}`)
          return resolve(res.text)
        })
    })
  res.send(JSON.stringify({
    'status': 'API sent'
  }));
});


app.listen(port, function() {
  console.log('Sender App listening on port ' + port + ' !!');
});








// sendmail();
