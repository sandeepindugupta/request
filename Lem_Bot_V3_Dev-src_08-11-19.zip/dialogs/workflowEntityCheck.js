// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { InputHints, MessageFactory,ActivityTypes,TurnContext } = require('botbuilder');
const { NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
// const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');

const NUMBER_PROMPT='numberprompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class workflowEntityCheck extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'workflowEntityCheck');
        this.addDialog(new NumberPrompt(NUMBER_PROMPT, this.EntityLengthCheck.bind(this)))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
                this.initialStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }
    

    async initialStep(stepContext) {
        
        const entity_id = stepContext.options.Entity_id;
        console.log("entity in initial step of check",entity_id);       
// I can open a ticket to report the issue 'Unable to see assigned workflow'. What's the 8 digit Legal Entity Directory ID?" 
        // const promptMessage=MessageFactory.suggestedActions(['Cancel'],"I can open a ticket to report the issue" + "'" + entity_id.wf_issue_type + "'"."\nWhat’s the **8 digit Legal Entity Directory ID**?")

        const promptMessage=MessageFactory.suggestedActions(['Cancel'],"I can open a ticket to report the issue " + "'" + stepContext.options.wf_type + "'.\n" + "What’s the **8 digit Legal Entity Directory ID**?")
        const repromptMessage = MessageFactory.suggestedActions(['Cancel'], "Sorry, that doesn't look right. Please provide the **8 digit Entity Directory ID (Swiss Re ID)**\n\n*Type Cancel to exit LEM help and talk about something else.*");
               
        if (!entity_id ) {
            console.log("123entity id check");
            return await stepContext.prompt(NUMBER_PROMPT,
                {
                    prompt: promptMessage,
                    retryPrompt: repromptMessage
                });
        }       
        if (entity_id.length!=8) { 
            
            
            console.log("checking reprompt");
            // This is essentially a "reprompt" of the data we were given up front.
            return await stepContext.prompt(NUMBER_PROMPT, { prompt: repromptMessage });
          
        }
        console.log("else condition of entity check");     
        return await stepContext.next(entity_id);
    }

    async finalStep(stepContext) {
        const entity_id = stepContext.result; 
        console.log("entity id in entity check",entity_id); 

        return await stepContext.endDialog(entity_id);
    }

async EntityLengthCheck(stepContext) 
{          
     if (stepContext.state.attemptCount<=3)
     {
        if (stepContext.recognized.succeeded)           
          {   
             if ((stepContext.recognized.value).toString().length == 8 ) 
             {         
                  return true;       
             }
             else if(stepContext.state.attemptCount == 3)
             {
                 return true; 
             }
              
          }
           return false;
       
    }
    else if(stepContext.state.attemptCount > 3)
        {
            return true;
        }   
}
}

module.exports.workflowEntityCheck = workflowEntityCheck;
