// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ConfirmPrompt, TextPrompt,NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { CardFactory } = require('botbuilder-core');
const { Entity_ID_check } = require('./Entity_ID_check');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const finance_card = require('./AdaptiveCards/financeData.json');
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const ENTITYIDCHECK = 'Entity_ID_check';
const WATERFALL_DIALOG = 'waterfallDialog';
const NUMBER_PROMPT='numberprompt';
class financeDataUpdate extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'financeDataUpdate');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))
            .addDialog(new Entity_ID_check(ENTITYIDCHECK))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                 this.financeType.bind(this),
                this.financialDetails.bind(this),               
                this.confirmStep.bind(this),
                this.finalStep.bind(this),          
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

   
   async EntityID(stepContext) {
         const bookingDetails = stepContext.options;
        
        const Intent_ent_json = { "intent_value" : "finance data",
            "entity_id_value":  bookingDetails.entity_id_value
            
        }
        console.log("finanace entity :::",bookingDetails);
        console.log("sdfsdf", bookingDetails.entity_id_value);
         if (!bookingDetails.entity_id_value || (bookingDetails.entity_id_value).length != 8) {
             console.log("entity fucntion");
            return await stepContext.beginDialog("Entity_ID_check", Intent_ent_json);
            
         }
         else
         {
             return await stepContext.next(bookingDetails.entity_id_value);
         }
   }

   
    async financeType(stepContext) {
        const bookingDetails = stepContext.options;
  console.log("financeTypeEEEEE functiom:@",stepContext.options);
       if(stepContext.result.toString().length != 8)
            {
                return await stepContext.endDialog();
            }
        bookingDetails.entityID = stepContext.result;
        console.log("Step contxet****",stepContext.result);
        if (!bookingDetails.financeType) {
            console.log("insideTTTTT types");
             const financeCard = CardFactory.adaptiveCard(finance_card);
          await stepContext.context.sendActivity({attachments: [financeCard] });
           return await stepContext.prompt('textPrompt', '');

        } 
    
        else {
            return await stepContext.next(bookingDetails.finance_type_value);
        }
        
    }
    
    async financialDetails(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.finance_type_value = stepContext.result.toLowerCase();
        console.log("stepContext.result in address$$",stepContext.result);
        
          var  newfinanceType;
        if (bookingDetails.finance_type_value.startsWith ("update"))
        {
            console.log("newAddressType", stepContext.result.toLowerCase());
             newfinanceType=bookingDetails.finance_type_value.slice(7,);
        }
        else
        {
            newfinanceType=bookingDetails.finance_type_value;
        }
        
        if (!bookingDetails.financeDetails) {
            // return await stepContext.prompt(TEXT_PROMPT, { prompt: 'What’s the correct '+`**${newfinanceType}**` +' **data** ? \nPlease type or paste it in full.'  });
            return await stepContext.prompt(TEXT_PROMPT, { prompt: "Please enter the "+`**${newfinanceType}**`+' field/s need to update, with its respective details' 
+' ? \nPlease type or paste it in full.' });
        } else {
            return await stepContext.next(bookingDetails.financeDetails_value);
            
        }
    }
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.financeDetails = stepContext.result;
        
          
          var  newfinanceType;
        if (bookingDetails.finance_type_value.toLowerCase().startsWith ("update"))
        {
            
             newfinanceType=bookingDetails.finance_type_value.slice(7,);
        }
        else
        {
            newfinanceType=bookingDetails.finance_type_value;
        }
        
        const Text = [
                     ];


await stepContext.context.sendActivity("Thanks, this is what you’hv told me:\n\n**Updated finance data**\n**Entity ID**: "+ bookingDetails.entityID +'\n **New**\t'+`**${newfinanceType}**` +" **data**"+":\t\t"+ bookingDetails.financeDetails);
const card = CardFactory.heroCard('', undefined,
            Text, { text:"Do you want to submit this request?" });


return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });

        
        
        
            
    }
    
   
    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;
             console.log("Inside final step of finance **",bookingDetails);
            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

module.exports.financeDataUpdate = financeDataUpdate;