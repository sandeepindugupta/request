// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { InputHints, MessageFactory,ActivityTypes,TurnContext } = require('botbuilder');
const { NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');

const NUMBER_PROMPT='numberprompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class cmsEntityCheck extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'cmsEntityCheck');
        this.addDialog(new NumberPrompt(NUMBER_PROMPT, this.EntityLengthCheck.bind(this)))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
                this.initialStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }
    

    async initialStep(stepContext) {
        const entity_id = stepContext.options.entityID;
        console.log("entity in initial step of check",stepContext);
        
         
        const promptMessage= MessageFactory.suggestedActions(['Cancel'], "Sure, I can open a ticket to get you a CMS number. What’s the **8 digit Legal Entity Directory ID (Swiss Re ID)**?");
       
        const repromptMessage =  MessageFactory.suggestedActions(['Cancel'], "Sorry, that doesn't look right. Please provide the **8 digit Entity Directory ID (Swiss Re ID)**\n\n*Type Cancel to exit LEM help and talk about something else.*");
        if (!entity_id ) {
            // We were not given any entity at all so prompt the user.
            console.log("123");
            return await stepContext.prompt(NUMBER_PROMPT,
                {
                    prompt: promptMessage,
                    retryPrompt: repromptMessage
                });
        }       
        if (entity_id.length!=8) {           
            // This is essentially a "reprompt" of the data we were given up front.
            return await stepContext.prompt(NUMBER_PROMPT, { prompt: repromptMessage });
        }     
        return await stepContext.next(entity_id);
    }

    async finalStep(stepContext) {
        const entity_id = stepContext.result; 
        console.log("entity id in entity check",entity_id); 
        return await stepContext.endDialog(entity_id);
    }

    async EntityLengthCheck(stepContext) 
{          
     if (stepContext.state.attemptCount<=3)
     {
        if (stepContext.recognized.succeeded)           
          {   
             if ((stepContext.recognized.value).toString().length == 8 ) 
             {         
                  return true;       
             }
             else if(stepContext.state.attemptCount == 3)
             {
                 return true; 
             }
              
          }
           return false;
       
    }
    else if(stepContext.state.attemptCount > 3)
        {
            return true;
        }   
}
}

module.exports.cmsEntityCheck = cmsEntityCheck;
