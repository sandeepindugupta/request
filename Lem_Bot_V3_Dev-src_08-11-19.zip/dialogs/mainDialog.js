// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext,BotFrameworkAdapter, MemoryStorage, ConversationState, UserState } = require('botbuilder');
const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ComponentDialog, DialogSet, DialogTurnStatus, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { EntityEditorsUpdate } = require('./EntityEditorsUpdate');
const { LuisHelper } = require('./luisHelper');
const {addressUpdate}=require('./addressUpdate');
const{ cmsUpdate}=require('./cmsUpdate');
const {financeDataUpdate}=require('./financeDataUpdate');
const {taxDataUpdate}=require('./taxDataUpdate');
const {workflowDataUpdate}=require('./workflowDataUpdate');
const {statusCode}= require('./statusCode');
const {OtherQueries}= require('./OtherQueries');
const {starmind}= require('./starmind');
const welcome_LEM = require('./AdaptiveCards/Lem_NewWelcome.json');
const { CardFactory } = require('botbuilder-core');
const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
const TEXT_PROMPT = 'textPrompt';
const ENTITY_EDITORS_UPDATE = 'EntityEditorsUpdate';
const ADDRESS_UPDATE='addressUpdate';
const CMS_UPDATE='cmsUpdate';
const FINANCE_DATA_UPDATE='financeDataUpdate';
const TAX_DATA_UPDATE='taxDataUpdate';
const OTHER_QUERIES = 'OtherQueries';
const WORKFLOW_DATA_UPDATE='workflowDataUpdate';
const STATUS_CODE='statusCode';
const STARMIND='starmind';

var appInsights = require('applicationinsights');

appInsights.setup(process.env.AppInsightkey)
                .setAutoDependencyCorrelation(true)
                .setAutoCollectRequests(true)
                .setAutoCollectPerformance(true)
                .setAutoCollectExceptions(true)
                .setAutoCollectDependencies(true)
                .setUseDiskRetryCaching(true)
                .start();
var appInsightsClient = appInsights.defaultClient;

// const CONVERSATION_DATA_PROPERTY = 'conversationData';
// const USER_PROFILE_PROPERTY = 'userProfile';
class MainDialog extends ComponentDialog {
    constructor(logger) {
        super('MainDialog');
        //  this.conversationData = conversationState.createProperty(CONVERSATION_DATA_PROPERTY);
        // this.userProfile = userState.createProperty(USER_PROFILE_PROPERTY);
        
        // this.conversationState = conversationState;
        // this.userState = userState;

        if (!logger) {
            logger = console;
            logger.log('[MainDialog]: logger not passed in, defaulting to console');
        }

        this.logger = logger;

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new EntityEditorsUpdate(ENTITY_EDITORS_UPDATE))
            .addDialog(new addressUpdate(ADDRESS_UPDATE))
            .addDialog(new cmsUpdate(CMS_UPDATE))
            .addDialog(new financeDataUpdate(FINANCE_DATA_UPDATE))
            .addDialog(new taxDataUpdate(TAX_DATA_UPDATE))
            .addDialog(new workflowDataUpdate(WORKFLOW_DATA_UPDATE))
            .addDialog(new statusCode(STATUS_CODE))
            .addDialog(new OtherQueries(OTHER_QUERIES))
            .addDialog(new starmind(STARMIND))
            .addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
            this.actStep.bind(this),
            this.finalStep.bind(this)
        ]));

        this.initialDialogId = MAIN_WATERFALL_DIALOG;
    }


    /**
     * The run method handles the incoming activity (in the form of a DialogContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {*} dialogContext
     */
    async run(turnContext, accessor) {
    const dialogSet = new DialogSet(accessor);
    dialogSet.add(this);

    const dialogContext = await dialogSet.createContext(turnContext);
    const results = await dialogContext.continueDialog();



    console.log("status result", results.status);
    console.log("status result", turnContext);
    console.log("accessor is ", accessor);

    if (results.status === DialogTurnStatus.empty) {
        await dialogContext.beginDialog(this.id);
    }
}
    async actStep(stepContext) {
        let bookingDetails = {};
        let bookingDetails1 = {};
        console.log("Inside actstep :::flow 3", bookingDetails.intent);
        
        appInsightsClient.trackEvent({ 
                                name: "LEM Complete utterance", 
                                properties: { 
                                        Query: stepContext.context.activity.text, 
                                        conversation_Id: stepContext.context.activity.conversation.id, 
                                        timestamp: stepContext.context.activity.timestamp 
                                } 
                              });
        
      /*  var request = require("request");

var options = { method: 'POST',
  url: 'http://drona-np.swissre.com/email',
  headers: 
   { 'cache-control': 'no-cache',
     Connection: 'keep-alive',
     'content-length': '',
     'accept-encoding': 'gzip, deflate',
     Host: 'drona-np.swissre.com',
     'Postman-Token': '8d96fb20-0cb2-4480-87a3-da4f86d88555,f3422b96-b704-4016-a9b2-dc24cbec365f',
     'Cache-Control': 'no-cache',
     Accept: '*//*',
     'User-Agent': 'PostmanRuntime/7.11.0' } };

request(options, function (error, response, body) {
  if (error) throw new Error(error);

  console.log("check the function API ", body);
});*/
        
        
        
        
        
        

        if (process.env.LuisAppId && process.env.LuisAPIKey && process.env.LuisAPIHostName) {
            console.log("Inside Luis ");
            bookingDetails = await LuisHelper.executeLuisQuery(this.logger, stepContext.context);

            this.logger.log('Luis found intent:', bookingDetails);
        }

        if (bookingDetails.intent == 'LEM_Queries') {
            
            // await stepContext.context.sendActivity("check microsoft");
           
           // var reply = createEvent("changeBackground", stepContext.context.activity.text, session.message.address);
          /* const reply = { type: ActivityTypes.Event };
            reply.text = 'Trigger API function';
            // reply.attachments = [this.getInlineAttachment()];
           // var reply = MessageFactory.suggestedActions(['Yes', 'No'], 'Is there anything else I can help you with?');
           console.log("check the reply", reply);
          return await stepContext.context.sendActivity(reply);*/
            
           return await stepContext.endDialog();
        }
        // else if (bookingDetails.intent == 'Legal_entitty_bsns_issues') {
        //     const Issues_LE_bsns_data1 = CardFactory.adaptiveCard(Issues_LE_bsns_data);
        //     return await stepContext.context.sendActivity({ attachments: [Issues_LE_bsns_data1] });
            
        // }
         else if (bookingDetails.intent == "Entity_data_updation") {
            return await stepContext.endDialog();
        } 
      
        // else if (bookingDetails.intent == 'Other_LEM/LPE_data_issue') {
        //     return await stepContext.endDialog();
          
        // }
        
        else if (bookingDetails.intent == 'Entity_address') {
             console.log("csm updation3");
            return await stepContext.beginDialog("addressUpdate", bookingDetails);


        }
         else if (bookingDetails.intent == 'EntityEditorsUpdate') {

            return await stepContext.beginDialog("EntityEditorsUpdate", bookingDetails);


        }
        else if (bookingDetails.intent == 'FAQs_related_to_LEM') {
            
        return await stepContext.beginDialog("starmind", bookingDetails);

        }
        //***** CMS Updation****
         else if (bookingDetails.intent == 'Entity_CMS') {
             console.log("csm updation");




            return await stepContext.beginDialog("cmsUpdate", bookingDetails);


        }
        else if (bookingDetails.intent == "Entity_finance") {
          return await stepContext.beginDialog("financeDataUpdate", bookingDetails);
            
            
        
        }else if (bookingDetails.intent == "Workflow_queries") {
           return await stepContext.beginDialog("workflowDataUpdate", bookingDetails);
        
        }
        
         else if (bookingDetails.intent == "tax_data") {
            return await stepContext.beginDialog("taxDataUpdate", bookingDetails);
        }
         else if (bookingDetails.intent== "Auxiliary_operations"){
            /*var json=   {
                                "action": "handover",
                               "message": "No updates"
                                
                            }
              var json1=JSON.stringify(json);*/
             await stepContext.context.sendActivity("No updatesss"); 
             return stepContext.endDialog();
         }
         
        else if (bookingDetails.intent == 'Open_ticket_for_all_other_legal_entity_queries'){            

             return await stepContext.beginDialog("OtherQueries", bookingDetails);           
        }
        else if (bookingDetails.intent == "None") {
            
            let text_value;
           text_value = stepContext.context.activity.text;
           // here we are getting ticket details          
            
            if (stepContext.context.activity.text)
            { 
                // creating random number
                 var x = Math.floor((Math.random() * 90000000) + 10000000);
                   var requestId="RITM"+x;
                   
                // if(stepContext.context.activity.text.toLowerCase()=="yes"){
                //   const welcome_again = CardFactory.adaptiveCard(welcome_LEM);
                //   return await stepContext.context.sendActivity({ attachments: [welcome_again] });  
                // }else if(stepContext.context.activity.text.toLowerCase()=="no"){
                //   // stepContext.context.sendActivity("Thank you.Have a nice day! ");
                //   return await stepContext.endDialog();  
                // }
                //handling cancel from welcome message 
                //  else if(stepContext.context.activity.text.toLowerCase()=="cancel"){
                if(stepContext.context.activity.text.toLowerCase()=="cancel"){                  
                  
                 var json=   {
                                "action": "handover"
                                
                            }            
              var json1=JSON.stringify(json);
              await stepContext.context.sendActivity(json1);
                    
       
                    
                }
                //ckecking with status code 
                else if(text_value.includes("code"))
                {               
                    return await stepContext.beginDialog("statusCode", stepContext.context.activity.text);   
                }
                else{
                    
                    // Sorry message use case
                   
                    var json={
                        
                             "action": "handover",
                             "message": stepContext.context.activity.text , 
                             "request_id":requestId,
                             "reason": 4 


                    }
                    var json1=JSON.stringify(json);
                console.log("sorry message");
                stepContext.context.sendActivity("Thanks! I’ve sent your request and one of my human colleagues will be in touch soon");
                // stepContext.context.sendActivity("I’m sorry, I don’t understand the question. Could you please try rephrasing it so that I can better assist you? I want to help.");
                return await stepContext.endDialog();
                }
            }          
       
        } else 
        {
            return await stepContext.endDialog();
        }

    }


async finalStep(stepContext) {   
    if (stepContext.result) {
        const result = stepContext.result;     
        // Now we have all the booking details.
        const msg = "Thanks! I’ve sent your request and one of my human colleagues will be in touch soon.";
        await stepContext.context.sendActivity(msg);
        var x = Math.floor((Math.random() * 90000000) + 10000000);
       var requestId="RITM"+x;
        console.log("request id",requestId);
    console.log("flow 4 final step",stepContext);
    if(result.intent=='Entity_address'){
          var  newAddressType;
        if (result.address_type_value.toLowerCase().startsWith ("update"))
        {
           
             newAddressType=result.address_type_value.slice(7,);         
        }
        else
        {
            newAddressType=result.address_type_value;
        }
         var cust_comm= "Entity ID: "+ result.entityID +"\n"+" New\t"+newAddressType +": "+ result.address ;
        var shortDesc="Update address for an entity";
        //  var shortDesc="I want to update my " +`${newAddressType}` + " following are details:-"+"entityId : "+`${result.entityID}`+",New "+`${newAddressType}`+":"+`${result.address}`;
         var json={
            "action": "create_inc_ticket",
            "customer_communication":cust_comm ,
            "short_description":shortDesc ,
            "ticket_status": "1",       
            "call_code": "Chat Bot",
             "assignment_group": "CEDD Operations   ",
             "priority": 4,
             "category": "inquiry",
             "service_offering": "Legal Entities" , 
             "configuration_item": "LEM",   
            "request_id":requestId 
        }
        
    }
    else if(result.intent=='tax_data'){
          var  newTaxType;
        if (result.tax_type_value.toLowerCase().startsWith ("update"))
        {
           
             newTaxType=result.tax_type_value.slice(7,);         
        }
        else
        {
            newTaxType=result.tax_type_value;
        }
          var cust_comm= "Entity ID: "+ result.entityID +"\n"+" New\t"+newTaxType +": "+ result.taxDetails ;
     var shortDesc= "Update tax data on an entity"; 
        //  var shortDesc="I want to update my " +`${newTaxType}`+" data" + " following are details:-"+"entityId : "+`${result.entityID}`+",New "+`${newTaxType}`+" data"+":"+`${result.taxDetails}`;
         var json={
            "action": "create_inc_ticket",
            "customer_communication":cust_comm ,
            "short_description":shortDesc ,
            "ticket_status": "1",       
            "call_code": "Chat Bot",
             "assignment_group": "CEDD Operations   ",
             "priority": 4,
             "category": "inquiry",
             "service_offering": "Legal Entities" , 
             "configuration_item": "LEM ",  
            "request_id":requestId  
        }
        
    }
   else if(result.intent=='Entity_finance') {
        var  newFinanceType;
        if (result.finance_type_value.toLowerCase().startsWith ("update"))
        {
           
             newFinanceType=result.finance_type_value.slice(7,);             
        }
        else
        {
            newFinanceType=result.finance_type_value;
        }
         var cust_comm= "Entity ID: "+ result.entityID +"\n"+" New\t"+newFinanceType +": "+ result.financeDetails ;
        //  var shortDesc="I want to update my " +`${newFinanceType}`+" data" + " following are details:-"+"entityId : "+`${result.entityID}`+",New "+`${newFinanceType}`+" details"+":"+`${result.financeDetails}`;
       var shortDesc="Update finance details on an entity";
         var json={
           "action": "create_inc_ticket",
            "customer_communication":cust_comm ,
            "short_description":shortDesc ,
            "ticket_status": "1",       
            "call_code": "Chat Bot",
             "assignment_group": "CEDD Operations   ",
             "priority": 4,
             "category": "inquiry",
             "service_offering": "Legal Entities" , 
             "configuration_item": "LEM",   
            "request_id":requestId
        }
        
   } else if(result.intent=='Workflow_queries'){
          var cust_comm= "Entity ID: "+ result.entityID +"\n"+" Workflow issue: "+result.workflow_type_value +"\nDescription: "+ result.workflowDetails_value ;        
        var shortDesc="Workflow issue on an entity";
        //  var shortDesc="I am having issue on workflow following are details:-"+"entityId : "+`${result.entityID}`+",Workflow issue type :"+`${result.workflow_type_value}`+" ,workflow issue description"+":"+`${result.workflowDetails_value}`;
         var json={
           "action": "create_inc_ticket",
            "customer_communication":cust_comm ,
            "short_description":shortDesc ,
            "ticket_status": "1",       
            "call_code": "Chat Bot",
             "assignment_group": "CEDD Operations   ",
             "priority": 4,
             "category": "inquiry",
             "service_offering": "Legal Entities" , 
             "configuration_item": "LEM",   
            "request_id":requestId
        }
       
   }
   else if(result.intent == 'Open_ticket_for_all_other_legal_entity_queries')
   {
       var shortDesc= result.descrptn;    
    
         var json={
           "action": "create_inc_ticket",
            "customer_communication":shortDesc,
            "short_description":"General legal entity business query" ,
            "ticket_status": "1",       
            "call_code": "Chat Bot",
             "assignment_group": "CEDD Operations   ",
             "priority": 4,
             "category": "inquiry",
             "service_offering": "Legal Entities" , 
             "configuration_item": "LEM ",   
            "request_id":requestId
        }
   }
   else if(result.intent=='EntityEditorsUpdate'){
   var cust_comm= "Entity ID: "+ result.entityID +"\n"+"New "+result.editorType_value +":  "+ result.editorName_value ;
   var shortDesc="Update a listed editor or responsible on an entity";
    // var shortDesc="I want to update my " +`${result.editorType_value}` + " following are details:-"+"entityId : "+`${result.entityID}`+",New "+`${result.editorType_value}`+" details"+":"+`${result.editorName_value}`;
         var json={
        "action": "create_inc_ticket",
            "customer_communication":cust_comm ,
            "short_description":shortDesc ,
            "ticket_status": "1",       
            "call_code": "Chat Bot",
             "assignment_group": "CEDD Operations   ",
             "priority": 4,
             "category": "inquiry",
             "service_offering": "Legal Entities" , 
             "configuration_item": "LEM ",   
            "request_id":requestId
        }
   }
      else if(result.intent=='Entity_CMS'){
      var cust_comm= "Entity ID: "+ result.entityID;
      console.log("Check entity ID: ",result.entityID );
     var shortDesc='Retrieve CMS number for a legal entity';     
    
         var json={
           "action": "create_inc_ticket",
            "customer_communication":cust_comm ,
            "short_description":shortDesc ,
            "ticket_status": "1",       
            "call_code": "Chat Bot",
             "assignment_group": "CEDD Operations   ",
             "priority": 4,
             "category": "inquiry",
             "service_offering": "Legal Entities" , 
             "configuration_item": "LEM ",   
            "request_id":requestId                 
        }
   } 
       var json1=JSON.stringify(json);
       
       
        await stepContext.context.sendActivity(json1);
        //  await stepContext.context.sendActivity(msg);
        // const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
        // await timeout(3000);
        // var reply = MessageFactory.suggestedActions(['Yes', 'No'], 'Is there anything else I can help you with?');
        //           await stepContext.context.sendActivity(reply);
    }
    
    
    else {
         var json={
                        
                             "action": "handover",
                             "reason": 1
                   }
                    var json1=JSON.stringify(json);
         console.log("in else part of finalStep Mian js-------------------------",stepContext);
         await stepContext.context.sendActivity(json1);
         //await stepContext.context.sendActivity();
       
    }
    return await stepContext.endDialog();
}
}

module.exports.MainDialog = MainDialog;