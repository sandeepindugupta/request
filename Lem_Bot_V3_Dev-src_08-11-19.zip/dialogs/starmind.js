// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {AttachmentLayoutTypes,ActionTypes,ActivityTypes,MessageFactory,ActivityHandler,TurnContext} = require('botbuilder');
const { ChoicePrompt, ListStyle,ConfirmPrompt, TextPrompt,NumberPrompt,ComponentDialog, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { Entity_ID_check } = require('./Entity_ID_check');
// var request = require("request");
var request = require("request-promise");


const { CardFactory } = require('botbuilder-core');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const ENTITYIDCHECK = 'Entity_ID_check';
const WATERFALL_DIALOG = 'waterfallDialog';
const NUMBER_PROMPT='numberprompt';
const CARD_PROMPT='cardPrompt';
const CHOICE_PROMPT = 'CHOICE_PROMPT';
// const productsPrompt = new ChoicePrompt(PRODUCTS_CAROUSEL);
// productsPrompt.style = ListStyle.none;
// const PRIVATE_CONVERSATION_DATA_PROPERTY = 'privateconversationData';


class starmind extends ComponentDialog {
    constructor(id) {
        super(id || 'starmind');
        
        this.addDialog(new TextPrompt(TEXT_PROMPT))
            // .addDialog(productsPrompt)
            .addDialog(new ChoicePrompt('cardPrompt'))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))
            .addDialog(new Entity_ID_check(ENTITYIDCHECK))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                 this.addressType.bind(this),
                this.address.bind(this)               
                // this.confirmStep.bind(this),  
                // this.finalStep.bind(this)       
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

   
    
    async EntityID(stepContext) {
    
        
        
        const bookingDetails = stepContext.options;
        
        return await stepContext.prompt('textPrompt', 'Please enter query to fetch'); 
    }
    
    
    
    async addressType(stepContext) {
        
  	 
        var bookingDetails = stepContext.options;
        const queryStarmind= stepContext.result;    
        // console.log("accepting input from user",bookingDetails);
        console.log("checking  result",stepContext.result);
        
     var responseOne='';
     var responseTwo='';
var responseRes=await firstFun(stepContext);
return await stepContext.next(responseRes);
async function firstFun(stepContext)
{
    try{
        console.log("inside first fxn")
        responseOne= await tokenFxn();
        responseTwo= await starmindResponse(responseOne);
    if(responseTwo!=null){
        //  return await stepContext.next(responseTwo);
        return responseTwo;
 
  }
    }catch(error){
        console.log(error);
    }
}

async function tokenFxn()
 {
   return await new Promise(function (resolve, reject)
{
       var options = { method: 'POST',
 url: 'https://swissre.starmind.com/api/v1/auth/login',
 headers:
  { 'postman-token': '7d1925f6-35fc-20b0-60aa-ef9d7658a64f',
    'cache-control': 'no-cache',
    'x-auth-apikey': 'kjhb2342398z423hjvx234xjhnkjoiuo34',
    accept: 'application/json',
    'content-type': 'application/json' },
 body:
  { email: 'TECDRRT1_Service@swissre.com',
    password: 'poiu234nklklj2469lkj' },
 json: true };

request(options, function (error, response, body) {

 if (!error) {
    //  stepContext.token=body.token;
               resolve(body.token);
           } else {
               reject(error);
           }

});

});
}


async function starmindResponse(responseOne){
return await new Promise(function (resolve, reject)
{
   // var token=stepContext;
   var auth= "Bearer "+responseOne;
   console.log("token",auth);

var options = { method: 'GET',
 url: 'https://swissre.starmind.com/api/v1/questions',
 qs: { query: queryStarmind },
 headers:
  { 'postman-token': 'bcb29682-dbec-93db-2c1e-1679a3129dca',
    'cache-control': 'no-cache',
    authorization: auth,
    'content-type': 'application/json',
    'x-auth-apikey': 'kjhb2342398z423hjvx234xjhnkjoiuo34' } };



request(options, function (error, response, body) {

if (error) throw new Error(error);

 var respo=JSON.parse(body);

 

// console.log("inside starmind",respo.items[0].title);


//  resolve(respo.items[0].title);
resolve(respo);
 

});
});
}

    
    }
     

 
   
    async address(stepContext) {
        const bookingDetails = stepContext.options;
        // console.log("options ##",stepContext);
        // console.log("length of starmind title",stepContext.result.items.length);
         console.log("total of starmind",stepContext.result.total);
        console.log("after entity id check123",stepContext.result.items[0].id);
        
    // var heading=stepContext.result.items[0].title;
    
    
  
             if(stepContext.result.total>=9){
                  var card1= {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [
        {
            "type": "TextBlock",
            "text": "Let’s see if I can help. Take a look at the information I’ve found:",
            "wrap": true,
            "weight": "Bolder"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[0].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data":{"data1":stepContext.result.items[0].title,
              "value":stepContext.result.items[0].id}
              // "title": "Mailing"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[1].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[1].title,
              "title": "Business"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[2].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[2].title,
              "title": "Registered"
            },
            "height": "auto"
        }
        
         
        
    ]
}
var card2= {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [
        {
            "type": "TextBlock",
            "text": "Let’s see if I can help. Take a look at the information I’ve found:",
            "wrap": true,
            "weight": "Bolder"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[3].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data":stepContext.result.items[3].title,
              "title": "Mailing"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[4].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[4].title,
              "title": "Business"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[5].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[5].title,
              "title": "Registered"
            },
            "height": "auto"
        }
        
         
        
    ]
}
var card3= {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [
        {
            "type": "TextBlock",
            "text": "Let’s see if I can help. Take a look at the information I’ve found:",
            "wrap": true,
            "weight": "Bolder"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[6].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data":stepContext.result.items[6].title,
              "title": "Mailing"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[7].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[7].title,
              "title": "Business"
            },
            "height": "auto"
        },
        {
            "type": "Container",
            "items": [
                {
                    "type": "TextBlock",
                    "color": "dark",
                    "text": stepContext.result.items[8].title,
                    "horizontalAlignment": "center",
                    "wrap": true,
                    "height": "auto"
                }
            ],
              "style": "emphasis",
            "selectAction": {
              "type": "Action.Submit",
              "data": stepContext.result.items[8].title,
              "title": "Registered"
            },
            "height": "auto"
        }
        
         
        
    ]
}

               const Types1 = CardFactory.adaptiveCard(card1);
               const Types2 = CardFactory.adaptiveCard(card2);
               const Types3 = CardFactory.adaptiveCard(card3);
                await stepContext.context.sendActivity({attachments: [Types1,Types2,Types3], attachmentLayout: AttachmentLayoutTypes.Carousel});
               return await stepContext.prompt('textPrompt', '');
             }
             else if(stepContext.result.total==0 ||stepContext.result.total<0|| stepContext.result.total<9){
                 return await stepContext.context.sendActivity("I can’t find any information on this, give me another chance and ask in a different way (simple sentences work best).");
             }
        
       
    }
    async confirmStep(stepContext) {        
        const bookingDetails = stepContext.options;
        // Capture the results of the previous step
        bookingDetails.address = stepContext.result;
          var  newAddressType;
        if (bookingDetails.address_type_value.toLowerCase().startsWith ("update"))
        {
            console.log("newAddressType", stepContext.result.toLowerCase());
             newAddressType=bookingDetails.address_type_value.slice(7,);
        }
        else
        {
            newAddressType=bookingDetails.address_type_value;
        }
        
        const Text = [
                     ];
                     

// const card = CardFactory.heroCard('', undefined,
//             Text, { text: "Thanks, this is what you’hv told me:\n\n**Updated address data**\n\n**Entity ID** \t\t: "+ bookingDetails.entityID +'\n\n **New**\t'+`**${newAddressType}**` +':\t\t'+ bookingDetails.address +'\n\n **Do you want to submit this request?**\n'});
             
             
   console.log("address update step context$$",stepContext.options); 
          // await stepContext.prompt(CONFIRM_PROMPT,{prompt: { attachments: [card] }});
           // await stepContext.prompt('textPrompt', '')
          await stepContext.context.sendActivity("Thanks, this is what you’hv told me:\n\n**Updated address data**\n\n**Entity ID** \t\t: "+ bookingDetails.entityID +'\n\n **New**\t'+`**${newAddressType}**` +":\t\t"+ bookingDetails.address)
        //    var action=  MessageFactory.suggestedActions(['Yes','No'], "submit");
        //  return await stepContext.prompt(TEXT_PROMPT,action);
        //  return await stepContext.context.sendActivity(action);
        const card = CardFactory.heroCard('', undefined,
            Text, { text: "**Do you want to submit this request?**"});
 return await stepContext.prompt(CONFIRM_PROMPT, {prompt: { attachments: [card] } });
        
    }
    
   
     async finalStep(stepContext) {
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;
            console.log("inside final step of address ",bookingDetails);
            return await stepContext.endDialog(bookingDetails);
        }
        return await stepContext.endDialog();
    }
    
}

module.exports.starmind = starmind;