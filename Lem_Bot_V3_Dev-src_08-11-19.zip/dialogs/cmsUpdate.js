// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext,BotFrameworkAdapter, MemoryStorage, ConversationState, UserState } = require('botbuilder');
const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { CardFactory } = require('botbuilder-core');
const { cmsEntityCheck } = require('./cmsEntityCheck');
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const CMS_ENTITY_CHECK = 'cmsEntityCheck';
const WATERFALL_DIALOG = 'waterfallDialog';

class cmsUpdate extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'cmsUpdate');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new cmsEntityCheck(CMS_ENTITY_CHECK))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                this.confirmStep.bind(this),         
				this.finalStep.bind(this),
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

   

 async EntityID(stepContext) {
       const bookingDetails = stepContext.options;
             
         if (!bookingDetails.entity_id_value || (bookingDetails.entity_id_value).length != 8) {
             console.log("entity fucntion");
            return await stepContext.beginDialog("cmsEntityCheck", {entityID: bookingDetails.entity_id_value });            
         }
         else
         {
             return await stepContext.next(bookingDetails.entity_id_value);
         }
 }

   
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;
         bookingDetails.entityID = stepContext.result;
         if(stepContext.result.toString().length != 8)
            {
                console.log("ending the dialog");               
                return await stepContext.endDialog();
            }
            //For triggering the event from SDK
           /*const reply = { type: ActivityTypes.Event  };
            reply.name = 'Trigger_API';   
            reply.value = stepContext.result;       
           console.log("check the reply", reply);
          return await stepContext.context.sendActivity(reply);   */  
        
        //For Yada bot conersation - Uncomment this
      const Text = [
                     ];

      await stepContext.context.sendActivity("Thanks, this is what you’ve told me:\n\n**Retrieve CMS number for an entity**\n**Legal Entity ID:** "+ bookingDetails.entityID)

      const card = CardFactory.heroCard('', undefined,Text, { text: "Do you want to submit this request?" });
      return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
  
    }
    

    
    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;

            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

module.exports.cmsUpdate = cmsUpdate;