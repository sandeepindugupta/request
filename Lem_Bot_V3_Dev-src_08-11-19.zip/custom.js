// JS file by CG
$(document).ready(function(){
    $("#webchat").hide();
    $(".minimized").on("click", function() {
        $(".minimized").css("background", "white");
        $('.minimized').hide();
        $('.messages').hide();
        $('.minimizedClose').show();
        $('.closeChat').show();
        $(".minimized").css("display", "block");
        $(".closeChat").css("display", "inline-block");
        $("#webchat").show();
    });
    $(".minimizedClose").click(function() {
        $(".minimized").css("background", "#902a8e");
        $('#webchat').hide();
        $('.minimized').show();
        $('.messages').show();
        $('.minimizedClose').hide();
        $('.closeChat').hide();
    });
   
// //draggable function for chat window
var div = $('#webchat');
div.draggable(
{
    stop: function(event, ui)
    {
        var top = getTop(ui.helper);
        ui.helper.css('position', 'fixed');
        ui.helper.css('top', top+"px");
    }
});

function getTop(ele)
{
    var eTop = ele.offset().top;
    var wTop = $(window).scrollTop();
    var top = eTop - wTop;

    return top;
}

$("#webchat").draggable({
    containment: "window",
    handle:"#webchat",
    scroll:false
})

// //resizable chat window
$(function() {
    $( "#webchat" ).resizable({
      handles: "n, e, w, s, sw, se, nw, ne",
      containment: "html",
      scroll:false,
      minWidth: 350,
      minHeight: 460
    });
    });
});