// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { ActivityHandler, ConversationState, UserState } = require('botbuilder');
const { Dialog } = require('botbuilder-dialogs');
const { CardFactory } = require('botbuilder-core');
const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const CONFIRM_PROMPT = 'confirmPrompt';

class DialogBot extends ActivityHandler {   
      
    /**
     *
     * @param {ConversationState} conversationState
     * @param {UserState} userState
     * @param {Dialog} dialog
     * @param {any} logger object for logging events, defaults to console if none is provided
     */
    constructor(conversationState, userState, dialog, logger) {
        super();
        if (!conversationState) throw new Error('[DialogBot]: Missing parameter. conversationState is required');
        if (!userState) throw new Error('[DialogBot]: Missing parameter. userState is required');
        if (!dialog) throw new Error('[DialogBot]: Missing parameter. dialog is required');
        if (!logger) {
            logger = console;
            logger.log('[DialogBot]: logger not passed in, defaulting to console');
        }

        this.conversationState = conversationState;
        //this.addDialog(new ConfirmPrompt(CONFIRM_PROMPT))  
        this.userState = userState;
        this.dialog = dialog;
        this.logger = logger;
        this.dialogState = this.conversationState.createProperty('DialogState');
        
        this.onEvent(async (context, next) => {
          console.log("event name_actData: ",context.activity.value.actData);
          console.log("event name: ",context.activity.value.userInputValText);
                    const eventName = context.activity.name;
        
                   if (eventName == "CMSNumber" &&  context.activity.value.actData != null && context.activity.value.actData.responseText != "raise a ticket"){ 
                    console.log("event name1: ", context);
                    return await context.sendActivity("The CMS number is: " +context.activity.value.actData);
                   }
                   else if(context.activity.value.actData.responseText == "raise a ticket")
                        {
                            console.log("null value");
                        const Text = [
                                     ];
                              await context.sendActivity("I am unable to fetch the CMS ID. I will help you raising a ticket.\n\n This is what you’ve told me:\n\n**Retrieve CMS number for an entity.**\n\n**Entity ID:** "+ context.activity.value.userInputValText)
                                const card = CardFactory.heroCard('', undefined,
                             Text, { text:"Do you want to submit this request?"});

                return await context.sendActivity("Do you want to submit this request?");
                          //  return await context.endDialog();
                              // const card = CardFactory.heroCard('', undefined,Text, { text: "Do you want to submit this request?" });
                        
                        
                              // return await context.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
                        }
        
             
           });

        this.onMessage(async context => {
            this.logger.log('Running dialog with Message Activity.');

            // Run the Dialog with the new message Activity.
            await this.dialog.run(context, this.dialogState);

            // Save any state changes. The load happened during the execution of the Dialog.
            await this.conversationState.saveChanges(context, false);
            await this.userState.saveChanges(context, false);
        });
    }
}

module.exports.DialogBot = DialogBot;
