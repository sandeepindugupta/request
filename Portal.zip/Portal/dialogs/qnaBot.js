// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { ActivityHandler } = require('botbuilder');
const { QnAMaker } = require('botbuilder-ai');

class QnABot extends ActivityHandler {
    constructor() {
        super();

        try {
            this.qnaMaker = new QnAMaker({
                knowledgeBaseId: process.env.QnA_kb_Key,
                endpointKey: process.env.QnA_EndpointKey,
                host: process.env.QnA_Host
            });
        } catch (err) {
            console.warn(`QnAMaker Exception: ${ err } Check your QnAMaker configuration in .env`);
        }

       // If a new user is added to the conversation, send them a greeting message
        this.onMembersAdded(async (context, next) => {
            const membersAdded = context.activity.membersAdded;
            // await context.sendActivity('Welcome to the QnA Maker sample! Ask me a question and I will try to answer it.');
            for (let cnt = 0; cnt < membersAdded.length; cnt++) {
                if (membersAdded[cnt].id === context.activity.recipient.id) {
                    await context.sendActivity('<b>{ attachments: [welcomeCard] }</b>');
                }
            }

            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });

        // When a user sends a message, perform a call to the QnA Maker service to retrieve matching Question and Answer pairs.
        this.onMessage(async (context, next) => {
            if (!process.env.QnA_kb_Key || !process.env.QnA_EndpointKey || !process.env.QnA_Host) {
                let unconfiguredQnaMessage = 'NOTE: \r\n' + 
                    'QnA Maker is not configured. To enable all capabilities, add `QnAKnowledgebaseId`, `QnAEndpointKey` and `QnAEndpointHostName` to the .env file. \r\n' +
                    'You may visit www.qnamaker.ai to create a QnA Maker knowledge base.'

                 await context.sendActivity(unconfiguredQnaMessage)
            }
            else {
                console.log('Calling QnA Maker reached..');
    
                const qnaResults = await this.qnaMaker.getAnswers(context);
        console.log('qnaResults[0]',qnaResults);
                // If an answer was received from QnA Maker, send the answer back to the user.
                if (qnaResults[0]) {
                    // if(qnaResults[0].metadata[0].name=='qntype')
                    // {
                        
                    // }
                    console.log('qnaResults[0]',qnaResults[0]);
                    await context.sendActivity(qnaResults[0].answer);
    
                // If no answers were returned from QnA Maker, reply with help.
                } else {
                    await context.sendActivity('Sorry, I did not understand. Please rephrase your questions and ask me.');
                }
    
            }
            
            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });
    }
}

module.exports.QnABot = QnABot;