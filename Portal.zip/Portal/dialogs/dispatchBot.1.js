// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
// The accessor names for the conversation data and user profile state property accessors.

const accData = {
    "account": [{
        "id": "1234",
        "user_name": "john",
        "password": "john@123",
        "account_number": "123456789",
        "account_balance": "150028.96",
        "last_transaction_date": "20th jan 2020"
    }, {
        "id": "2345",
        "user_name": "smith",
        "password": "smith@123",
        "account_number": "9988776655",
        "account_balance": "25689.15",
        "last_transaction_date": "16th jan 2020"
    }],
    "credit_card": [{
        "id": "1345",
        "user_name": "john",
        "password": "john@123",
        "due_date": "20th jan 2020",
        "minimum_due": "1230.00",
        "current_outstanding": 76589.00,
        "last_billed_due": "0",
        "credit_limit": 150000
    }, {
        "id": "1245",
        "user_name": "smith",
        "password": "smith@123",
        "due_date": "18th jan 2020",
        "minimum_due": "1300.00",
        "current_outstanding": 65439.00,
        "last_billed_due": "0",
        "credit_limit": 250000
    }]
};

const CONVERSATION_DATA_PROPERTY = 'conversationData';
const USER_PROFILE_PROPERTY = 'userProfile';

const {
    ActivityHandler,
    InputHints
} = require('botbuilder');
const {
    LuisRecognizer,
    QnAMaker
} = require('botbuilder-ai');
const {
    CardFactory,
    MessageFactory
} = require('botbuilder-core');
class DispatchBot extends ActivityHandler {
    constructor(conversationState, userState) {
        super();
        // Create the state property accessors for the conversation data and user profile.
        this.conversationDataAccessor = conversationState.createProperty(CONVERSATION_DATA_PROPERTY);
        this.userProfileAccessor = userState.createProperty(USER_PROFILE_PROPERTY);

        // The state management objects for the conversation and user state.
        this.conversationState = conversationState;
        this.userState = userState;
        // If the includeApiResults parameter is set to true, as shown below, the full response
        // from the LUIS api will be made available in the properties  of the RecognizerResult
        const dispatchRecognizer = new LuisRecognizer({
            applicationId: process.env.LuisAppId,
            endpointKey: process.env.LuisAPIKey,
            endpoint: 'https://westus.api.cognitive.microsoft.com'
        }, {
            includeAllIntents: true,
            includeInstanceData: true
        }, true);

        const qnaMaker = new QnAMaker({
            knowledgeBaseId: process.env.QnA_kb_Key,
            endpointKey: process.env.QnA_EndpointKey,
            host: process.env.QnA_Host
        });

        this.dispatchRecognizer = dispatchRecognizer;
        this.qnaMaker = qnaMaker;

        this.onEvent(async (context, next) => {

            await context.sendActivity("event received!");

            await next();
        });


        this.onMessage(async (context, next) => {
            const userProfile = await this.userProfileAccessor.get(context, {});
            console.log("=Text From User=", context._activity.text);
            if (context._activity.text == 'Login Now' && !context._activity.value) {
                if (!userProfile.userTextLogIn) {
                    var cardAccountTypeIntent = {
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "type": "AdaptiveCard",
                        "version": "1.0",
                        "body": [{
                            "type": "TextBlock",
                            "text": "Login"
                        }, {
                            "type": "TextBlock",
                            "text": "User Id"
                        }, {
                            "type": "Input.Text",
                            "id": "userid",
                            "placeholder": "Please type your user id.",
                            "maxLength": 500
                        }, {
                            "type": "TextBlock",
                            "text": "Password"
                        }, {
                            "type": "Input.Text",
                            "id": "Password",
                            "placeholder": "Please type your password here.",
                            "style": "password",
                            "maxLength": 500
                        }],
                        "actions": [{
                            "type": "Action.Submit",
                            "title": "Login"
                        }]
                    }
                    const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
                    await context.sendActivity({
                        attachments: [wce]
                    }, {
                        attachments: [wce]
                    }, InputHints.IgnoringInput);
                } else {
                    await context.sendActivity("You are already logged in. Please continue with your banking related questions.");
                }
                await next();
            }
            // userProfile.userLoggedIn=false;
            else if (context._activity.value) {
                userProfile.userName = context._activity.value.userid;
                userProfile.passWord = context._activity.value.Password;
                // userProfile.userQuery = context._activity.text;
                // console.log(body);                
                var userName, passWord;
                // accData=JSON.parse(accData);
                var lengthOfAccountDetailsArr = accData.account.length;
                // console.log(accData);
                for (var i = 0; i < lengthOfAccountDetailsArr; i++) {
                    if (userProfile.userName == accData.account[i].user_name && userProfile.passWord == accData.account[i].password) {
                        userProfile.userLoggedIn = true;
                        userProfile.userTextLogIn = true;
                        await context.sendActivity("Hello " + userProfile.userName.charAt(0).toUpperCase() + userProfile.userName.slice(1) + ". You are logged in successfully.");
                        if (userProfile.latestIntent == 'AccountBalance' || userProfile.latestIntent == 'CreditLimit' || userProfile.latestIntent == 'creditCardDue') {
                            if (userProfile.userLoggedIn) {
                                const recognizerResult = await dispatchRecognizer.recognize(context);
                                await this.loggedInUserResponse(context, userProfile);
                            } else {
                                await context.sendActivity("Sorry, The details provided by your are not present in our directory.");
                            }
                        }
                        await this.userState.saveChanges(context, false);
                        break;
                    }
                }
                console.log('=====93', userProfile.latestIntent);
                // invokeLatestIntent(content,userProfile.latestIntent)   
                // if(!userProfile.userTextLogIn)
                // {    
                //      if (userProfile.userLoggedIn) {
                //         const recognizerResult = await dispatchRecognizer.recognize(context);
                //         await this.loggedInUserResponse(context, userProfile);
                //     } else {
                //         await context.sendActivity("Sorry, The details provided by your are not present in our directory.");
                //     }                    
                // }
                // else
                // {
                //         await context.sendActivity("How may I help you with your banking related questions?"); 
                //         userProfile.userTextLogIn=false;                   
                //         await this.userState.saveChanges(context, false);
                // }

                // await next();
                // return;

                console.log("Logged in user there", userProfile.userName);
            } else {
                console.log('Processing Message Activity.');
                // console.log("---------->",JSON.stringify(context));
                console.log("---------->", userProfile.userQuery);
                // First, we use the dispatch model to determine which cognitive service (LUIS or QnA) to use.
                const recognizerResult = await dispatchRecognizer.recognize(context);

                // Top intent tell us which cognitive service to use.
                const intent = LuisRecognizer.topIntent(recognizerResult);

                // Next, we call the dispatcher with the top intent.
                await this.dispatchToTopIntentAsync(context, intent, recognizerResult, userProfile);

                console.log("Its there", context._activity);
            }


            await next();
        });

        this.onMembersAdded(async (context, next) => {
            const welcomeText = 'Type a greeting or a question about the weather to get started.';
            const membersAdded = context.activity.membersAdded;

            for (const member of membersAdded) {
                if (member.id === context.activity.recipient.id) {
                    await context.sendActivity('<b>{ attachments: [welcomeCard] }</b>');
                    await context.sendActivity('<b>{ [welcomeCard] }</b>');
                }
            }

            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });
    }

    async loggedInUserResponse(context, userProfile) {
        // console.log("===========", intent);
        var intent = userProfile.latestIntent
        console.log('-----------userProfile', userProfile);
        // userProfile.latestIntent=intent;
        console.log('-----------userProfile.latestIntent', userProfile.latestIntent);

        // console.log('luisResult intent', recognizerResult.luisResult.topScoringIntent.score);

        switch (intent) {
            case 'AccountOpening':
                await this.processAccountOpening(context);
                break;
                // case 'ATM':
                //     await this.processATM(context, recognizerResult.luisResult);
                //     break;
            case 'SavingsAccount':
                await this.processSavingsAccount(context);
                break;
            case 'CurrentAccount':
                await this.processCurrentAccount(context);
                break;
            case 'InterestCheckingAccount':
                await this.processInterestCheckingAccount(context);
                break;
            case 'AlPromotionsAvailable':
                await this.processAlPromotionsAvailable(context);
                break;
            case 'CreditCard':
                await this.processCreditCard(context);
                break;
            case 'ApplyForCreditCard':
                await this.processApplyForCreditCard(context);
                break;
            case 'CancelCreditCard':
                await this.processCancelCreditCard(context);
                break;
            case 'NewCreditCard':
                await this.processNewCreditCard(context);
                break;
            case 'IntegratedDepositAccount':
                await this.processIntegratedDepositAccount(context);
                break;
            case 'Loans':
                await this.processLoans(context);
                break;
            case 'HouseLoan':
                await this.processHouseLoan(context);
                break;
            case 'EligibilityHL':
                await this.processEligibilityHL(context);
                break;
            case 'InterestRateHL':
                await this.processInterestRateHL(context);
                break;
            case 'DocumentsHL':
                await this.processDocumentsHL(context);
                break;
            case 'PersonalLoan':
                await this.processPersonalLoan(context);
                break;
            case 'EligibilityPL':
                await this.processEligibilityPL(context);
                break;
            case 'DocumentsPL':
                await this.processDocumentsPL(context);
                break;
            case 'InterestRatePL':
                await this.processInterestRatePL(context);
                break;
            case 'CarLoan':
                await this.processCarLoan(context);
                break;
            case 'InterestRateCL':
                await this.processInterestRateCL(context);
                break;
            case 'PrepayCarLoan':
                await this.processPrepayCarLoan(context);
                break;
            case 'Tenure':
                await this.processTenure(context);
                break;
            case 'Timeline':
                await this.processTimeline(context);
                break;
            case 'Limit':
                await this.processLimit(context);
                break;
            case 'Login':
                await this.processLogin(context);
                break;
            case 'CreditLimit':
                await this.processCreditLimit(context, userProfile);
                await this.userState.saveChanges(context, false);
                break;
            case 'creditCardDue':
                await this.processcreditCardDue(context, userProfile);
                await this.userState.saveChanges(context, false);
                break;
            case 'AccountBalance':
                await this.processAccountBalance(context, userProfile);
                // await this.conversationState.saveChanges(turnContext, false);
                await this.userState.saveChanges(context, false);
                break; 
            case 'CreditCardTransactions':
                await this.processCreditCardTransactions(context, userProfile);
                // await this.conversationState.saveChanges(turnContext, false);
                await this.userState.saveChanges(context, false);
                break;
            case 'LastCreditCardTransactions':
                await this.processCreditCardTransactions(context, userProfile);
                // await this.conversationState.saveChanges(turnContext, false); 
                await this.userState.saveChanges(context, false);
                break;    
            case 'tfund':
                await this.processTFund(context, userProfile);
                // await this.conversationState.saveChanges(turnContext, false);tfund 
                await this.userState.saveChanges(context, false);
                break;                             
            case 'RecentTransactions':
                await this.processRecentTransactions(context, userProfile);
                // await this.conversationState.saveChanges(turnContext, false);
                await this.userState.saveChanges(context, false);
                break;
            default:
                await this.processSampleQnA(context);
                await this.userState.saveChanges(context, false);
                // await context.sendActivity(`Dispatch unrecognized intent: ${ intent }.`);            
                break;

        }

    }



    async dispatchToTopIntentAsync(context, intent, recognizerResult, userProfile) {
        console.log("===========", intent);
        console.log('-----------userProfile', userProfile);
        userProfile.latestIntent = intent;
        console.log('-----------userProfile.latestIntent', userProfile.latestIntent);
        const resultsQna = await this.qnaMaker.getAnswers(context);
        console.log("===",resultsQna);
        console.log('luisResult intent', recognizerResult.luisResult.topScoringIntent.score);
        if(resultsQna && resultsQna[0] && (resultsQna[0].score >= 0.90))
        {
            if (resultsQna[0].score >= 0.90) {
             await this.processSampleQnA(context);
            await this.userState.saveChanges(context, false);
            
        } 
        }
        
        else if(recognizerResult.luisResult.topScoringIntent.score<=0.40)
        {
            await context.sendActivity('Sorry, I did not understand. Please rephrase your question.');
        }
        else {
           switch (intent) {
                case 'AccountOpening':
                    await this.processAccountOpening(context);
                    break;
                case 'ATM':
                    await this.processATM(context, recognizerResult.luisResult);
                    break;
                case 'SavingsAccount':
                    await this.processSavingsAccount(context);
                    break;
                case 'CurrentAccount':
                    await this.processCurrentAccount(context);
                    break;
                case 'InterestCheckingAccount':
                    await this.processInterestCheckingAccount(context);
                    break;
                case 'AlPromotionsAvailable':
                    await this.processAlPromotionsAvailable(context);
                    break;
                case 'CreditCard':
                    await this.processCreditCard(context);
                    break;
                case 'ApplyForCreditCard':
                    await this.processApplyForCreditCard(context);
                    break;
                case 'CancelCreditCard':
                    await this.processCancelCreditCard(context);
                    break;
                case 'NewCreditCard':
                    await this.processNewCreditCard(context);
                    break;
                case 'IntegratedDepositAccount':
                    await this.processIntegratedDepositAccount(context);
                    break;
                case 'Loans':
                    await this.processLoans(context);
                    break;
                case 'HouseLoan':
                    await this.processHouseLoan(context);
                    break;
                case 'EligibilityHL':
                    await this.processEligibilityHL(context);
                    break;
                case 'InterestRateHL':
                    await this.processInterestRateHL(context);
                    break;
                case 'DocumentsHL':
                    await this.processDocumentsHL(context);
                    break;
                case 'PersonalLoan':
                    await this.processPersonalLoan(context);
                    break;
                case 'EligibilityPL':
                    await this.processEligibilityPL(context);
                    break;
                case 'DocumentsPL':
                    await this.processDocumentsPL(context);
                    break;
                case 'InterestRatePL':
                    await this.processInterestRatePL(context);
                    break;
                case 'CarLoan':
                    await this.processCarLoan(context);
                    break;
                case 'InterestRateCL':
                    await this.processInterestRateCL(context);
                    break;
                case 'PrepayCarLoan':
                    await this.processPrepayCarLoan(context);
                    break;
                case 'Tenure':
                    await this.processTenure(context);
                    break;
                case 'Timeline':
                    await this.processTimeline(context);
                    break;
                case 'Limit':
                    await this.processLimit(context);
                    break;
                case 'Login':
                    await this.processLogin(context);
                    break;
                case 'CreditLimit':
                    await this.processCreditLimit(context, userProfile);
                    await this.userState.saveChanges(context, false);
                    break;
                case 'creditCardDue':
                    await this.processcreditCardDue(context, userProfile);
                    await this.userState.saveChanges(context, false);
                    break;
                case 'AccountBalance':
                    await this.processAccountBalance(context, userProfile);
                    // await this.conversationState.saveChanges(turnContext, false);
                    await this.userState.saveChanges(context, false);
                    break;
                case 'CreditCardTransactions':
                    await this.processCreditCardTransactions(context, userProfile);
                    // await this.conversationState.saveChanges(turnContext, false);
                    await this.userState.saveChanges(context, false);
                    break;
                case 'LastCreditCardTransactions':
                    await this.processCreditCardTransactions(context, userProfile);
                    // await this.conversationState.saveChanges(turnContext, false);
                    await this.userState.saveChanges(context, false);
                    break;                       
                case 'RecentTransactions':
                    await this.processRecentTransactions(context, userProfile);
                    // await this.conversationState.saveChanges(turnContext, false);
                    await this.userState.saveChanges(context, false);
                    break;
                case 'tfund':
                    await this.processTFund(context, userProfile);
                    // await this.conversationState.saveChanges(turnContext, false);tfund 
                    await this.userState.saveChanges(context, false);
                    break; 
                default:
                    console.log(`Dispatch unrecognized intent: ${ intent }.`);
                    await context.sendActivity('Sorry, I did not understand. Please rephrase your question.');            
                    break;
            }
        }
    }
    
    
    async dispatchToTopIntentAsync(context, intent, recognizerResult, userProfile) {
        await context.sendActivity('');
    }

    async processCreditCardTransactions(context, userProfile) {
        var cardAccountTypeIntent = {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [{
        "type": "TextBlock",
        "text": "Please find your latest credit card transactions below.",
        "wrap": "true"
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "weight": "bolder",
                    "text": "Date",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "weight": "bolder",
                    "text": "Transaction Name",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "weight": "bolder",
                    "text": "Amount"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "weight": "bolder",
                    "text": "Type"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "UPI/00098667/Paytm",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "2000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "NEFT-SIN27132847-m/DTP Techno/ACC",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "2000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "POSDEC CHG/16-12-2019",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "1000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "IIN/I-Debit/202000104567/Paytm",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "5000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "UPI/00098667/Paytm",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "3000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }]
}
            const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
            await context.sendActivity({
                attachments: [wce]
            }, {
                attachments: [wce]
            }, InputHints.IgnoringInput);
    }
    
    async processTFund(context, userProfile) {
              var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "Please choose one of the methods to transfer funds",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.OpenUrl",
                "title":   "UPI",
                "url": "www.capgemini.com"
            },
            {
                "type":   "Action.OpenUrl",
                "title":   "IMPS",
                "url": "www.capgemini.com"
            },
            {
                "type":   "Action.OpenUrl",
                "title":   "NEFT",
                "url": "www.capgemini.com"
            }			

            ,
            {
                "type":   "Action.OpenUrl",
                "title":   "RTGS",
                "url": "www.capgemini.com"
            }            
            ]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }
    
    
    async processRecentTransactions(context, userProfile) {
        
           var cardAccountTypeIntent = {
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [{
        "type": "TextBlock",
        "text": "Please find your latest credit card transactions below.",
        "wrap": "true"
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "weight": "bolder",
                    "text": "Date",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "weight": "bolder",
                    "text": "Transaction Name",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "weight": "bolder",
                    "text": "Amount"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "weight": "bolder",
                    "text": "Type"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "UPI/00098667/Paytm",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "2000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "NEFT-SIN27132847-m/DTP Techno/ACC",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "2000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "POSDEC CHG/16-12-2019",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "1000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "IIN/I-Debit/202000104567/Paytm",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "5000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }, {
        "type": "Container",
        "items": [{
            "type": "ColumnSet",
            "columns": [{
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "06 Jan '20"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "UPI/00098667/Paytm",
                    "wrap": true
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "3000"
                }],
                "width": "stretch"
            }, {
                "type": "Column",
                "items": [{
                    "type": "TextBlock",
                    "separator": true,
                    "text": "DR"
                }],
                "width": "stretch"
            }]
        }]
    }]
}
            const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
            await context.sendActivity({
                attachments: [wce]
            }, {
                attachments: [wce]
            }, InputHints.IgnoringInput);
        
    }



    async processCreditLimit(context, userProfile) {
        if (userProfile.userLoggedIn) {
            var current_outstanding, CreditLimit;
            var lengthOfAccountDetailsArr = accData.credit_card.length;
            // console.log(accData);
            for (var i = 0; i < lengthOfAccountDetailsArr; i++) {
                if (userProfile.userName == accData.credit_card[i].user_name && userProfile.passWord == accData.credit_card[i].password) {
                    // await context.sendActivity("Hello " + userProfile.userName.charAt(0).toUpperCase() + userProfile.userName.slice(1) + ". You are logged in successfully.");
                    // if (userProfile.latestIntent == 'CreditLimit') {
                    CreditLimit = accData.credit_card[i].credit_limit;
                    current_outstanding = accData.credit_card[i].current_outstanding;
                    // }
                    break;
                }
            }
            await context.sendActivity('Your net credit limit is ' + CreditLimit + ', and current limit is ' + current_outstanding);
        } else {
            var cardAccountTypeIntent = {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.0",
                "body": [{
                    "type": "TextBlock",
                    "text": "Please login to check credit limit"
                }, {
                    "type": "TextBlock",
                    "text": "User Id"
                }, {
                    "type": "Input.Text",
                    "id": "userid",
                    "placeholder": "Please type your user id.",
                    "maxLength": 500
                }, {
                    "type": "TextBlock",
                    "text": "Password"
                }, {
                    "type": "Input.Text",
                    "id": "Password",
                    "placeholder": "Please type your password here.",
                    "style": "password",
                    "maxLength": 500
                }],
                "actions": [{
                    "type": "Action.Submit",
                    "title": "Login"
                }]
            }
            const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
            await context.sendActivity({
                attachments: [wce]
            }, {
                attachments: [wce]
            }, InputHints.IgnoringInput);
        }
    }
    async processcreditCardDue(context, userProfile) {
        if (userProfile.userLoggedIn) {
            var creditCardDue;
            var lengthOfAccountDetailsArr = accData.credit_card.length;
            // console.log(accData);
            for (var i = 0; i < lengthOfAccountDetailsArr; i++) {
                if (userProfile.userName == accData.credit_card[i].user_name && userProfile.passWord == accData.credit_card[i].password) {
                    // await context.sendActivity("Hello " + userProfile.userName.charAt(0).toUpperCase() + userProfile.userName.slice(1) + ". You are logged in successfully.");
                    // if (userProfile.latestIntent == 'CreditLimit') {
                    creditCardDue = accData.credit_card[i].current_outstanding;
                    // }
                    break;
                }
            }
            await context.sendActivity('The current outstanding balance of your credit card is ' + creditCardDue + '.');
        } else {
            var cardAccountTypeIntent = {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.0",
                "body": [{
                    "type": "TextBlock",
                    "text": "Please login to check credit card outstanding"
                }, {
                    "type": "TextBlock",
                    "text": "User Id"
                }, {
                    "type": "Input.Text",
                    "id": "userid",
                    "placeholder": "Please type your user id.",
                    "maxLength": 500
                }, {
                    "type": "TextBlock",
                    "text": "Password"
                }, {
                    "type": "Input.Text",
                    "id": "Password",
                    "placeholder": "Please type your password here.",
                    "style": "password",
                    "maxLength": 500
                }],
                "actions": [{
                    "type": "Action.Submit",
                    "title": "Login"
                }]
            }
            const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
            await context.sendActivity({
                attachments: [wce]
            }, {
                attachments: [wce]
            }, InputHints.IgnoringInput);
        }
    }

    async processAccountBalance(context, userProfile) {

        console.log('userProfile', userProfile);
        if (userProfile.userLoggedIn) {
            var lengthOfAccountDetailsArr = accData.account.length;
            // console.log(accData);
            for (var i = 0; i < lengthOfAccountDetailsArr; i++) {
                if (userProfile.userName == accData.account[i].user_name && userProfile.passWord == accData.account[i].password) {
                    // await context.sendActivity("Hello " + userProfile.userName.charAt(0).toUpperCase() + userProfile.userName.slice(1) + ". You are logged in successfully.");
                    if (userProfile.latestIntent == 'AccountBalance') {
                        userProfile.accountBalance = accData.account[i].account_balance;
                    }
                    break;
                }
            }
            await context.sendActivity('Your account balance is Rs.' + userProfile.accountBalance);
        } else {
            var cardAccountTypeIntent = {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.0",
                "body": [{
                    "type": "TextBlock",
                    "text": "Please login to check account balance"
                }, {
                    "type": "TextBlock",
                    "text": "User Id"
                }, {
                    "type": "Input.Text",
                    "id": "userid",
                    "placeholder": "Please type your user id.",
                    "maxLength": 500
                }, {
                    "type": "TextBlock",
                    "text": "Password"
                }, {
                    "type": "Input.Text",
                    "id": "Password",
                    "placeholder": "Please type your password here.",
                    "style": "password",
                    "maxLength": 500
                }],
                "actions": [{
                    "type": "Action.Submit",
                    "title": "Login"
                }]
            }
            const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
            await context.sendActivity({
                attachments: [wce]
            }, {
                attachments: [wce]
            }, InputHints.IgnoringInput);
        }

        // await context.sendActivity({ attachments: [wce] });

        // await context.sendActivity('Which type of account are you interested in?');                                
    }


    async processLimit(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "For a New Car Loan, you can choose any repayment option from 12 to 84 months all specially designed to suit your requirements.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Interest rate for car loan",
                "data": "Interest rate for car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Prepay car loan",
                "data": "Prepay car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Tenure",
                "data": "Tenure"
            }, {
                "type":   "Action.Submit",
                "title":   "Timeline",
                "data": "Timeline"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processTimeline(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "For a New Car Loan, regular Bank customers can get a 10 minute instant inprinciple approval. Post-approval, the loan will be sanctioned within 4 hours on completion of required documentation. Instant loan disbursement under ZipDrive is also available for eligible bank customers.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Interest rate for car loan",
                "data": "Interest rate for car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Prepay car loan",
                "data": "Prepay car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Tenure",
                "data": "Tenure"
            }, {
                "type":   "Action.Submit",
                "title":   "Limit",
                "data": "Limit"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processTenure(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "For a New Car Loan, you can choose any repayment option from 12 to 84 months all specially designed to suit your requirements.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Interest rate for car loan",
                "data": "Interest rate for car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Prepay car loan",
                "data": "Prepay car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Timeline",
                "data": "Timeline"
            }, {
                "type":   "Action.Submit",
                "title":   "Limit",
                "data": "Limit"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }


    async processPrepayCarLoan(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "You can pre-pay or foreclose the loan any time after 6 months of availing of the loan. You will have to pay a small pre-payment fee on the outstanding loan amount.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Interest rate for car loan",
                "data": "Interest rate for car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Tenure",
                "data": "Tenure"
            }, {
                "type":   "Action.Submit",
                "title":   "Timeline",
                "data": "Timeline"
            }, {
                "type":   "Action.Submit",
                "title":   "Limit",
                "data": "Limit"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processInterestRateCL(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "The Rack interest rate for New Car Loan is 9.75% to 10.60% depending on the segment of vehicle. Please <a href='www.capgemini.com'>click here</a> for more details.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Prepay car loan",
                "data": "Prepay car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Tenure",
                "data": "Tenure"
            }, {
                "type":   "Action.Submit",
                "title":   "Timeline",
                "data": "Timeline"
            }, {
                "type":   "Action.Submit",
                "title":   "Limit",
                "data": "Limit"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processCarLoan(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "My Bank offers Car Finance up to 100% funding with attractive interest rates and up to 7 years tenure. Check out the various types of Car Loans here.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Interest rate for car loan",
                "data": "Interest rate for car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Prepay car loan",
                "data": "Prepay car loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Tenure",
                "data": "Tenure"
            }, {
                "type":   "Action.Submit",
                "title":   "Timeline",
                "data": "Timeline"
            }, {
                "type":   "Action.Submit",
                "title":   "Limit",
                "data": "Limit"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processDocumentsPL(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "Documents required for a Personal Loan are:\n1. Signed application form with photograph.\n2. ID and residence proof.\n3. Processing fee cheque.\n4. Last 6 months bank.\n5. Documentation for salaried applicants: Latest Salary-slip and Form 16 statements.\n6. Documentation for self-employed applicants: Education qualification certificate, proof of business existence, last 3 years Income Tax Returns with computation of Income, and last 3 years Profit/Loss and Balance Sheet.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Eligibility",
                "data": "Eligibility for Personal Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Interest Rate",
                "data": "Personal Loan Interest Rate"
            }, {
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processInterestRatePL(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "The rate of interest for personal loan varies between 10.75% to 21.30%. For detailed cost breakup and corresponding prices please <a href='www.capgemini.com'>click here</a>",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Eligibility",
                "data": "Eligibility for Personal Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Documents",
                "data": "Documents for Personal Loan"
            }, {
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processEligibilityPL(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "To be eligible for Personal Loan,\n1. The applicant should be between 21 and 60 years of age\n2. Should have a job for at least 2 years, with a minimum of 1 year with the current employer.\n3. Should earn a minimum of Rs. 15,000* net income per month. To know more, please <a href='www.capgemini.com'>click here.</a> Alternatively, you can also check your eligibility here.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Documents",
                "data": "Documents for Personal Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Interest Rate",
                "data": "Personal Loan Interest Rate"
            }, {
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processPersonalLoan(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "Personal loans will help you meet all your financial needs effectively, with simplified documentation and speedy approvals.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Eligibility",
                "data": "Eligibility for Personal Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Documents",
                "data": "Documents for Personal Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Interest Rate",
                "data": "Personal Loan Interest Rate"
            }, {
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processDocumentsHL(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "Documents required for a Home Loan are:\n1. Signed application form with photograph.\n2. ID and residence proof.\n3. Processing fee cheque.\n4. Last 6 months bank.\n5. Documentation for salaried applicants: Latest Salary-slip and Form 16statements.\n6. Documentation for self-employed applicants: Education qualification certificate, proof of business existence, last 3 years Income Tax Returns with computation of Income, and last 3 years Profit/Loss and Balance Sheet.",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Eligibility",
                "data": "Eligibility for House Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Interest Rate",
                "data": "House Loan Interest Rate"
            }, {
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processInterestRateHL(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "Home Loans are available starting from an interest rate of 8.35%. Please <a href='www.capgemini.com'>click here</a> to view all the rates, fees and charges for Home Loans",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Eligibility",
                "data": "Eligibility for House Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Documents",
                "data": "Documents for House Loan"
            }, {
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processEligibilityHL(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "Eligibility depends on various parameters such as age, income, type of employment etc. To check your eligibility, please <a href='www.capgemini.com'>click here.</a>",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Interest Rate",
                "data": "House Loan Interest Rate"
            }, {
                "type":   "Action.Submit",
                "title":   "Documents",
                "data": "Documents for House Loan"
            }, {
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processHouseLoan(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "MyBank brings home loans to your doorstep. Here are a few features, transparent dealing. All charges mentioned upfront while giving you the loan quote. No hidden charges Counseling and advisory services: It is a service which develops conclusions and recommendations that are presented to the customer for consideration and decison making",
                "wrap": "true"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Eligibility",
                "data": "Eligibility for House Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Interest Rate",
                "data": "House Loan Interest Rate"
            }, {
                "type":   "Action.Submit",
                "title":   "Documents",
                "data": "Documents for House Loan"
            }, {
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }



    async processATM(context, luisResult) {
        const locationDetails = {};
        const fromEntities = this.luisRecognizer.getEntities(luisResult);
        return await stepContext.beginDialog('atm', locationDetails);
        await context.sendActivity("We've made it easy to apply for a Savings Account through our website. Just click the 'Apply Now' button to start the process. You'll will have to visit one of our branches to complete the Savings Account opening process.");
    }

    async processLoans(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "Which loan are you looking for?",
                // "size":   "Large",
                //"weight": "Bolder"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "House Loan",
                "data": "House Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Personal Loan",
                "data": "Personal Loan"
            }, {
                "type":   "Action.Submit",
                "title":   "Car Loan",
                "data": "Car Loan"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
        // await context.sendActivity({ attachments: [wce] });

        // await context.sendActivity('Which type of account are you interested in?');                                
    }

    async processAccountOpening(context) {
        var cardAccountTypeIntent =


            {
                "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
                "type":   "AdaptiveCard",
                "version":   "1.0",
                "body": [{
                    "type":   "TextBlock",
                    "text":   "Which type of account are you interested in?",
                    "size":   "Large",
                    //"weight": "Bolder"
                }],
                "actions": [{
                    "type":   "Action.Submit",
                    "title":   "Savings Account",
                    "data": "Savings Account"
                }, {
                    "type":   "Action.Submit",
                    "title":   "Current Account",
                    "data": "Current Account"
                }, {
                    "type":   "Action.Submit",
                    "title":   "Interest Checking Account",
                    "data": "Interest Checking Account"
                }]
            };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
        // await context.sendActivity({ attachments: [wce] });

        // await context.sendActivity('Which type of account are you interested in?');                                
    }

    async processIntegratedDepositAccount(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "If you have an existing current or savings account with us, simply login Online Banking to apply for an additional Integrated Deposits Account. If you do not have an existing current or savings account with us, please click like link below to start your applicaiton",
                // "size":   "Large",
                "wrap": "true",
                // "spacing"
                //"weight": "Bolder"
            }],
            "actions": [{
                "type":   "Action.OpenUrl",
                "title":   "Apply Now",
                "url": "www.capgemini.com"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
        // await context.sendActivity({ attachments: [wce] });

        // await context.sendActivity('Which type of account are you interested in?');                                
    }

    async processCreditCard(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "What promotion are you interested in?",
                "size":   "Large",
                //"weight": "Bolder"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "All",
                "data": "All promotional offers"
            }, {
                "type":   "Action.Submit",
                "title":   "Air Miles",
                "data": "Air Miles promotional offers"
            }, {
                "type":   "Action.Submit",
                "title":   "CashBack",
                "data": "CashBack Offers"
            }, {
                "type":   "Action.Submit",
                "title":   "Amazon Coupons",
                "data": "Amazon Coupons"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
        // await context.sendActivity({ attachments: [wce] });

        // await context.sendActivity('Which type of account are you interested in?');                                
    }
    async processSavingsAccount(context) {
        var cardAccountTypeIntent = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [{
                "type": "TextBlock",
                "wrap": "true",
                "text": "We've made it easy to apply for a Savings Account through our website. Just click the 'Apply Now' button to start the process. You'll will have to visit one of our branches to complete the Savings Account opening process."
            }],
            "actions": [{
                "type": "Action.OpenUrl",
                "title": "Apply Now",
                "url": "www.capgemini.com"
            }]

        };
        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);

    }

    async processCurrentAccount(context) {
        var cardAccountTypeIntent = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [{
                "type": "TextBlock",
                "wrap": "true",
                "text": "We've made it easy to apply for a current account through our website. Just click the 'Apply Now' button to start the process. You'll have to visit a branch to complete the current account opening process."
            }],
            "actions": [{
                "type": "Action.OpenUrl",
                "title": "Apply Now",
                "url": "www.capgemini.com"
            }]
        };

        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);

    }

    async processInterestCheckingAccount(context) {

        await context.sendActivity("If you have an existing current or savings account with us, simply login Online Banking to apply for an additional Integrated Deposits Account. If you do not have an existing current or savings account with us, please click like link below to start your applicaiton");

    }

    async processAlPromotionsAvailable(context) {

        await context.sendActivity("You can learn about all our exciting offers on our website. If you bookmark the link, you'll find it much easier to keep up to date with our latest promotions.");
    }

    async processApplyForCreditCard(context) {

        await context.sendActivity('Applying for a credit card is easy. Just fill in our online form. Have a look at our credit card options and let us know which card you are interested in. <br> <input type="button" value="Apply Now" >');
    }

    async processCancelCreditCard(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "As much as I would like to see you stay, you can contact us at xxxxxxx to arrange the cancellation of your credit card.",
                "size":   "Large",
                //"weight": "Bolder"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Talk to Live Agent",
                "data": "Talk to Live Agent"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processNewCreditCard(context) {
        var cardAccountTypeIntent = {
            "$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
            "type":   "AdaptiveCard",
            "version":   "1.0",
            "body": [{
                "type":   "TextBlock",
                "text":   "We can provide you with a replacement credit card. Please give my colleagues a call at xxxxxx. You can also find them online.",
                "size":   "Large",
                //"weight": "Bolder"
            }],
            "actions": [{
                "type":   "Action.Submit",
                "title":   "Talk to Live Agent",
                "data": "Talk to Live Agent"
            }]
        };


        const wce = CardFactory.adaptiveCard(cardAccountTypeIntent);
        await context.sendActivity({
            attachments: [wce]
        }, {
            attachments: [wce]
        }, InputHints.IgnoringInput);
    }

    async processSampleQnA(context) {
        console.log('processSampleQnA');

        const results = await this.qnaMaker.getAnswers(context);
        console.log("===",results);
        if (results.length > 0) {
            await context.sendActivity(`${ results[0].answer }`);
        } else {
            await context.sendActivity('Sorry, could not find an answer in the Q and A system.');
        }
    }
}

module.exports.DispatchBot = DispatchBot;