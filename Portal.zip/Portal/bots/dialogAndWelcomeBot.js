// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { CardFactory } = require('botbuilder');
const { DialogBot } = require('./dialogBot');
const WelcomeCard = require('./resources/welcomeCard.json');

class DialogAndWelcomeBot extends DialogBot {
    constructor(conversationState, userState, dialog) {
          console.log("---------");
        super(conversationState, userState, dialog);    
// Sends welcome messages to conversation members when they join the conversation.
// Messages are only sent to conversation members who aren't the bot.
this.onMembersAdded(async (context, next) => {
            //     await context.sendActivity('Welcome to the \'Welcome User\' Bot. This bot will introduce you to welcoming and greeting users.');
            // await context.sendActivity("You are seeing this message because the bot received at least one 'ConversationUpdate' " +
            //     'event, indicating you (and possibly others) joined the conversation. If you are using the emulator, ' +
            //     'pressing the \'Start Over\' button to trigger this event again. The specifics of the \'ConversationUpdate\' ' +
            //     'event depends on the channel. You can read more information at https://aka.ms/about-botframework-welcome-user');
            // await context.sendActivity('It is a good pattern to use this event to send general greeting to user, explaining what your bot can do. ' +
            //     'In this example, the bot handles \'hello\', \'hi\', \'help\' and \'intro\'. ' +
            //     'Try it now, type \'hi\'');
    // Iterate over all new members added to the conversation
    for (const idx in context.activity.membersAdded) {
        // Greet anyone that was not the target (recipient) of this message.
        // Since the bot is the recipient for events from the channel,
        // context.activity.membersAdded === context.activity.recipient.Id indicates the
        // bot was added to the conversation, and the opposite indicates this is a user.
        if (context.activity.membersAdded[idx].id === context.activity.recipient.id) {
            await context.sendActivity('Welcome to the \'Welcome User\' Bot. This bot will introduce you to welcoming and greeting users.');
            await context.sendActivity("You are seeing this message because the bot received at least one 'ConversationUpdate' " +
                'event, indicating you (and possibly others) joined the conversation. If you are using the emulator, ' +
                'pressing the \'Start Over\' button to trigger this event again. The specifics of the \'ConversationUpdate\' ' +
                'event depends on the channel. You can read more information at https://aka.ms/about-botframework-welcome-user');
            await context.sendActivity('It is a good pattern to use this event to send general greeting to user, explaining what your bot can do. ' +
                'In this example, the bot handles \'hello\', \'hi\', \'help\' and \'intro\'. ' +
                'Try it now, type \'hi\'');
        }
    }

    // By calling next() you ensure that the next BotHandler is run.
    await next();
});
        // this.onMembersAdded(async (context, next) => {
        //     console.log("---------s");
        //     // await context.sendActivity('<b>{ attachments: [welcomeCard] }</b>');
        //     // await dialog.run(context, conversationState.createProperty('DialogState'));
        //     const membersAdded = context.activity.membersAdded;
        //     console.log(membersAdded);
        //     for (let cnt = 0; cnt < membersAdded.length; cnt++) {
        //         if (membersAdded[cnt].id != context.activity.recipient.id) {
        //             const welcomeCard = CardFactory.adaptiveCard(WelcomeCard);
        //             // await context.sendActivity({ attachments: [welcomeCard] });
        //             await context.sendActivity('<b>{ attachments: [welcomeCard] }</b>');
        //             await dialog.run(context, conversationState.createProperty('DialogState'));
        //         }
        //     }
        //     // By calling next() you ensure that the next BotHandler is run.
        //     await next();
        // });
    }
}

module.exports.DialogAndWelcomeBot = DialogAndWelcomeBot;
